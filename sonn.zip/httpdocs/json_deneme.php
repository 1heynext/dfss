<?php

// SMS Gönderme
$data = array(
    "users" =>array(
        "username"=>"evosms",
        "password"=>"kt7735"
    ),
    "DataCoding"=>"Default",
    "Header"=>array(
      "Sender"=>"Forum"
    ),
    "Message" =>"mesaj",
    "Number" =>"5445509678",
    "Blacklist"=>"false"
);


// Bakiye Sorgulama
$data2 = array(
  "users" =>array(
      "username"=>"evosms",
      "password"=>"kt7735"
  )
);

// Message ID  : 43973
//Credit": 185411

// Bakiye dönen sonç
/*
{ "Response": { "Status": { "Code": 0, "Description": "" }, "Balance": { "Credit": "185408" } } }
*/

// Mesaj Dönen Sonuç
/*
{ "Response": { "Status": { "Code": 0, "Description": "İşlem başarılı." }, "MessageId": 43976 } }
*/

$data_string = json_encode($data);

$header_type =array('Content-Type: application/json');

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"https://api.vuxpanel.com/Json/Submit");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_HTTPHEADER,$header_type);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, 120);
	$result = curl_exec($ch);
  echo $result;

// https://api.vuxpanel.com/Json/Submit
// $ch = curl_init('https://api.vuxpanel.com/Json/Balance');
// curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
// curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
// curl_setopt($ch, CURLOPT_HTTPHEADER, array(
//     'Content-Type: application/json',
//     'Content-Length: ' . strlen($data_string))
// );
//
// $result = curl_exec($ch);
//
// echo $result;
