<?php

require_once "header.php";
require_once "left.php";

?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Kullanıcılar</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Kayıtlı Kullanıcılar</h4>
                            <hr>

                            <?php
                            $kull = $pdo->query("SELECT * FROM kullanicilar ORDER BY id DESC");
                            if($kull->rowCount() ==0 ) {
                              uyari("Kayıtlı Kullanıcı Bulunamadı");
                            } else {
                              ?>
                              <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                  <thead>
                                  <tr>
                                      <th>Kullanıcı Adı</th>
                                      <th>Parola</th>
                                      <th>Bakiye</th>
                                      <th>Fatura İşlemleri</th>
                                      <th>İşlemler</th>
                                  </tr>
                                  </thead>

                                  <tbody>
                                    <?php
                                      while(false !== $k = $kull->fetch(PDO::FETCH_OBJ)) {
                                        ?>
                                        <tr>
                                            <td><?=$k->kul_adi;?></td>
                                            <td>*****</td>
                                            <td><?=$k->bakiye;?></td>
                                            <td><a href="fatura">Fatura Ekle<i class="mdi mdi-image-frame"></i></a></td>
                                            <td> <a href="" alt="Düzenle"><img src="assets/images/duzenle.png"></a> </i>
                                              <a href=""><img src="assets/images/sil.png" alt="Sil"></a> </i>
                                             </td>
                                        </tr>
                                        <?php
                                      }
                                    ?>
                                  </tbody>
                              </table>
                              <?php

                            }

                             ?>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->




        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
