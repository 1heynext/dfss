<?php


$veri  ='{ "Response": { "Status": { "Code": 0, "Description": "İşlem başarılı." }, "MessageId": 43976 } }';

//var_dump(json_decode($veri));
$obj = json_decode($veri);
echo  $obj->Response->MessageId;
