<?php

header("Location:kullanici/login.php");
exit();