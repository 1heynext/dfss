<?php
ob_start();
	// Veritabanı Bağlantısı PDO ile yapılıyor
		$pdo = new PDO("mysql:host=localhost;dbname=tabi_sms_x_;charset=utf8;","tabi_sms_x","fee4cWALpe2gw9~",[
			PDO::ATTR_EMULATE_PREPARES => false,
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
		]);

		$pdo->exec("SET NAMES 'utf8'"); // Veritabanı karakter seti düzenleniyor.
		session_start();

?>