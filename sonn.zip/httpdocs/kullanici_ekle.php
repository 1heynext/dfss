<?php

require_once "header.php";
require_once "left.php";

?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Kullanıcılar</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <!-- end page-title -->

            <div class="row">
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                          <?php

                            if(isset($_GET)) {
                              if(isset($_GET["action"])){
                                if($_GET["action"]=="k_kaydet") {

                                    $kul_adi = $_POST["kul_adi"];
                                    $parola  = $_POST["parola"];
                                    $bakiye  = $_POST["bakiye"];

                                      if($kul_adi=="" || $parola =="" || $bakiye =="" ||  $bakiye ==0) {
                                          uyari("Lütfen Boş Alan Bırakmayınız");
                                        }elseif(!is_numeric($bakiye)) {
                                          uyari("Lütfen Girilen Numarayı Kontrol Ediniz.");
                                        } else {
                                          $kaydet = $pdo->prepare("insert into kullanicilar values(NULL,:kul_adi,:parola,:parola_md5,:bakiye)");

                                          $kaydet->bindValue(":kul_adi",$kul_adi,PDO::PARAM_STR);
                                          $kaydet->bindValue(":parola",$parola,PDO::PARAM_STR);
                                          $kaydet->bindValue(":parola_md5",md5($parola),PDO::PARAM_STR);
                                          $kaydet->bindValue(":bakiye",$bakiye,PDO::PARAM_INT);

                                          $kaydet->execute();
                                          if($kaydet->rowCount()>0) {
                                            bilgi("Bilgiler Kaydedildi.");
                                          } else {
                                            uyari("HATA : Bilgiler Kaydedilemedi. Daha Sonra Tekrar Deneyin");
                                          }

                                        }
                                }
                              }

                            }





                          ?>
                            <h4 class="mt-0 header-title">Kullanıcı Ekle</h4>
                            <form method="post" action="?action=k_kaydet">
                                <div class="form-group">
                                    <label>Kullanıcı Adı</label>
                                    <input type="text" name="kul_adi" class="form-control" required placeholder="Kullanıcı Adı"/>
                                </div>

                                <div class="form-group">
                                    <label>Parola</label>
                                    <div>
                                        <input type="password" name="parola" id="pass2" class="form-control" required
                                               placeholder="Parola"/>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>SMS Bakiyesi</label>
                                    <div>
                                        <input type="number"  name="bakiye" class="form-control" required
                                               parsley-type="email" placeholder="Sayısal Değer Giriniz"/>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">
                                            Kaydet
                                        </button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
