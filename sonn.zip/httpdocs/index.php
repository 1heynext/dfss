<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabisms - Anasayfa</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;707&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            color: #fff;
            overflow-x: hidden;
            position: relative;
        }

        /* Dekoratif Arka Plan Objeleri */
        .bg-objects {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }

        .planet {
            position: absolute;
            border-radius: 50%;
            box-shadow: 0 0 20px rgba(107, 72, 255, 0.5);
        }

        .planet.purple {
            width: 150px;
            height: 150px;
            top: 10%;
            left: 10%;
            background: linear-gradient(145deg, #6b48ff, #a29bfe);
            animation: float 10s infinite ease-in-out;
        }

        .planet.dog-planet {
            width: 100px;
            height: 100px;
            bottom: 15%;
            right: 10%;
            background: linear-gradient(145deg, #ff6b6b, #ff8e53);
            animation: float 12s infinite ease-in-out;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }

        /* Header */
        .site-header {
            padding: 20px 50px;
            background: transparent;
            position: relative;
            z-index: 10;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .logo {
            display: flex;
            flex-direction: column;
        }

        .logo img {
            max-width: 250px;
            height: auto;
        }

        .nav-buttons {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
            color: #666; /* Yazı rengi siyah ile gri arasında (orta koyu gri) */
        }

        .btn.green {
            background: #00ff7f;
        }

        .btn.pink {
            background: #ff147f;
        }

        .btn.yellow {
            background: #ffeb3b;
        }

        .header-container .btn:hover {
            opacity: 0.9;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.3);
            color: #fff; /* Hover durumunda yazı rengi beyaz */
        }

        .btn svg {
            width: 18px;
            height: 18px;
        }

        /* Hero Bölümü */
        .login-hero-section {
            padding: 50px 20px;
            position: relative;
            z-index: 5;
        }

        .login-hero-container {
            display: flex;
            flex-wrap: wrap;
            max-width: 1200px;
            margin: 0 auto;
            gap: 40px;
            justify-content: center;
            align-items: flex-start;
            padding: 0 20px;
        }

        .login-hero-left, .login-hero-right {
            flex: 1 1 400px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .login-hero-left {
            flex-direction: row;
            gap: 40px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .promo-text-content {
            flex: 1;
            min-width: 300px;
            max-width: 400px;
        }

        /* Banner Carousel */
        .banner-carousel {
            width: 100%;
            position: relative; /* Butonun ve çizginin carousel'in üzerine yerleştirilmesi için */
            margin-bottom: 20px;
        }

        .banner-container {
            position: relative;
            width: 100%;
        }

        .banner-slide {
            display: none; /* Varsayılan olarak tüm banner'lar gizli */
            width: 100%;
            position: relative; /* Çizginin banner'a göre konumlanması için */
        }

        .banner-slide.active {
            display: block; /* Sadece aktif banner görünür */
        }

        .banner-slide img {
            width: 100%; /* Tam sığdırmak için */
            height: auto;
            border-radius: 15px 15px 12px 12px; /* Alt kenarları çizgiye uygun şekilde oval */
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

        /* Pembe Çizgi (Banner için - U Şekli, Sola Kaydırılmış) */
        .banner-slide::after {
            content: '';
            position: absolute;
            bottom: 0; /* Banner'ın tam alt kenarına hizala */
            left: -5px; /* Sola kaydırılmış */
            width: 100%; /* Banner'ın tam genişliği (boyut korunuyor) */
            height: 30px; /* Çizginin yukarı çıkma mesafesi (banner için yaklaşık 30px) */
            border-bottom: 4px solid #ff147f; /* Alt kenar */
            border-left: 4px solid #ff147f; /* Sol kenar */
            border-right: 4px solid #ff147f; /* Sağ kenar */
            border-top: none; /* Üst kenar açık */
            border-radius: 0 0 12px 12px; /* Alt kenarlarda daha yumuşak oval şekil */
            z-index: 0; /* Banner'ın arkasında, butonun önünde */
        }

        /* Sağ/Sol Ok Butonları */
        .carousel-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 20, 127, 0.8);
            color: #fff;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background 0.3s;
            z-index: 1; /* Çizginin ve banner'ın önünde */
        }

        .carousel-nav:hover {
            background: #ff147f;
        }

        .prev-btn {
            left: 10px;
        }

        .next-btn {
            right: 10px;
        }

        .carousel-nav svg {
            width: 20px;
            height: 20px;
        }

        .promo-stats {
            display: flex;
            gap: 30px;
            margin: 20px 0;
            justify-content: center;
        }

        .promo-stats div {
            text-align: center;
        }

        .promo-stats svg {
            width: 32px;
            height: 32px;
            margin-bottom: 10px;
        }

        .promo-stats strong {
            color: #00ff7f;
            font-size: 16px;
        }

        .promo-stats span {
            font-size: 14px;
            color: #fff;
        }

        .promo-text {
            font-size: 14px;
            color: #ccc;
            max-width: 360px;
            margin: 0 auto;
        }

        .promo-image {
            /* Görsel kaldırıldığı için sadece boş bir kapsayıcı */
            flex: 1;
            min-width: 300px;
            max-width: 400px;
            position: relative;
        }

        .start-btn {
            background: #ff147f;
            padding: 12px 24px;
            font-weight: 700;
            font-size: 13px;
            border: none;
            border-radius: 30px;
            color: #666; /* Yazı rengi siyah ile gri arasında (orta koyu gri) */
            box-shadow: 0 0 12px #ff147f99;
            cursor: pointer;
            transition: all 0.3s;
            position: absolute; /* Carousel'in üzerine yerleştirme */
            bottom: 20px; /* Carousel'in alt kısmına hizalama */
            left: 50%; /* Ortaya hizalama */
            transform: translateX(-50%); /* Ortaya tam hizalama */
            text-decoration: none;
            z-index: 1; /* Çizginin üstünde görünmesi için */
        }

        .start-btn:hover {
            box-shadow: 0 0 20px #ff147f;
            color: #fff; /* Hover durumunda yazı rengi beyaz */
        }

        /* Kayıt Formu */
        .form-box {
            background: #2a2a4a;
            padding: 30px;
            border-radius: 15px 15px 0 0; /* Alt kenarları düzleştir, üst kenarları oval bırak */
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            max-width: 400px;
            width: 100%;
            position: relative; /* Çizginin kutuya göre konumlanması için */
        }

        /* Yeşil Çizgi (Form için - U Şekli, Sola Kaydırılmış) */
        .form-box::after {
            content: '';
            position: absolute;
            bottom: 0; /* Kutu alt kenarına hizala */
            left: -5px; /* Sola kaydırılmış */
            width: 100%; /* Kutunun tam genişliği (boyut korunuyor) */
            height: 60px; /* Çizginin yukarı çıkma mesafesi */
            border-bottom: 4px solid #00ff7f; /* Alt kenar */
            border-left: 4px solid #00ff7f; /* Sol kenar */
            border-right: 4px solid #00ff7f; /* Sağ kenar */
            border-top: none; /* Üst kenar açık */
            border-radius: 0 0 12px 12px; /* Alt kenarlarda daha yumuşak oval şekil */
        }

        .form-title {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .input-icon {
            position: absolute;
            top: 50%;
            left: 15px;
            transform: translateY(-50%);
            width: 18px; /* SVG ikonlarının boyutu */
            height: 18px;
            fill: #fff; /* Renksiz modern ikonlar için beyaz */
        }

        .input-group input {
            width: 100%;
            padding: 12px 12px 12px 40px;
            border: none;
            border-radius: 10px;
            background: #3a3a5a;
            color: #fff;
            font-size: 14px;
        }

        .submit-button {
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s; /* Hover için geçiş efekti */
            color: #666; /* Yazı rengi siyah ile gri arasında (orta koyu gri) */
        }

        .submit-button.green {
            background: #00ff7f;
        }

        .submit-button.orange {
            background: #ff9800;
        }

        .submit-button:hover {
            color: #fff; /* Hover durumunda yazı rengi beyaz */
        }

        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
            font-size: 14px;
        }

        .form-options a {
            color: #ff147f;
            text-decoration: none;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .checkbox-label input {
            width: 16px;
            height: 16px;
        }

        .checkbox-label a {
            color: #ff147f;
            text-decoration: none;
        }

        .login-prompt {
            font-size: 14px;
            color: #ccc;
            margin-bottom: 10px;
            text-align: center;
        }

        /* İlk Alt Bölüm */
        .bottom-section {
            padding: 50px 20px;
            position: relative;
            z-index: 5;
            background: transparent;
        }

        .bottom-container {
            display: flex;
            flex-wrap: wrap;
            max-width: 1200px;
            margin: 0 auto;
            gap: 40px;
            justify-content: center;
            align-items: center;
            padding: 0 20px;
        }

        .bottom-left, .bottom-right {
            flex: 1 1 400px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            position: relative; /* Çizgi için konumlandırma */
        }

        .bottom-left {
            max-width: 400px;
        }

        .bottom-left img {
            width: 100%;
            height: auto;
            border-radius: 15px;
            display: block;
        }

        /* Üstteki Görsel için Yeşil Çerçeve */
        .bottom-left::after {
            content: '';
            position: absolute;
            bottom: 0; /* Görselin tam alt kenarına hizala */
            left: -2px; /* Çok hafif sola kaydırdık */
            width: 100%; /* Görselin tam genişliği */
            height: 30px; /* Çizginin yukarı çıkma mesafesi */
            border-bottom: 4px solid #00ff7f; /* Alt kenar */
            border-left: 4px solid #00ff7f; /* Sol kenar */
            border-right: 4px solid #00ff7f; /* Sağ kenar */
            border-top: none; /* Üst kenar açık */
            border-radius: 0 0 12px 12px; /* Alt kenarlarda oval şekil */
            z-index: 0;
        }

        .bottom-right {
            display: flex;
            flex-direction: column;
            align-items: flex-start; /* Tüm içeriği sola hizala */
            gap: 20px;
            text-align: left; /* Yazıyı sola hizala */
            width: 100%; /* Tüm genişliği kapla */
        }

        .bottom-right .main-text {
            font-size: 32px;
            font-weight: 700;
            color: #fff;
            text-transform: uppercase;
            line-height: 1;
            margin-left: 10px; /* Tik işaretleriyle hizalamak için aynı boşluk */
        }

        .bottom-right .highlight-text {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 24px;
            font-weight: 700;
            color: #00ff7f;
            margin-left: 10px; /* Tik işaretleriyle hizalamak için aynı boşluk */
        }

        .bottom-right .highlight-text img {
            max-height: 50px;
            height: auto;
        }

        .bottom-right .green-line {
            width: 80%;
            height: 4px;
            background: #00ff7f;
            border-radius: 2px;
            margin: 20px 0;
            margin-left: 10px; /* Tik işaretleriyle hizalamak için aynı boşluk */
        }

        .bottom-right .features {
            display: flex;
            flex-direction: column;
            gap: 15px;
            align-items: flex-start; /* Sol tarafa hizalama */
            text-align: left; /* Metni sola hizala */
            width: 100%; /* Tüm genişliği kapla */
            margin-left: 10px; /* Hafif sağa kaydırma */
        }

        .bottom-right .feature-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            color: #fff;
        }

        .bottom-right .feature-item .check-circle {
            width: 24px;
            height: 24px;
            background: #00ff7f;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .bottom-right .feature-item .check-circle svg {
            width: 16px;
            height: 16px;
            fill: #fff;
        }

        /* İkinci Alt Bölüm */
        .bottom-section-2 {
            padding: 50px 20px;
            position: relative;
            z-index: 5;
            background: transparent;
        }

        .bottom-container-2 {
            display: flex;
            flex-wrap: wrap;
            max-width: 1200px;
            margin: 0 auto;
            gap: 40px;
            justify-content: center;
            align-items: center;
            padding: 0 20px;
        }

        .bottom-left-2, .bottom-right-2 {
            flex: 1 1 400px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            position: relative; /* Çizgi için konumlandırma */
        }

        .bottom-right-2 {
            max-width: 400px;
        }

        .bottom-right-2 img {
            width: 100%;
            height: auto;
            border-radius: 15px;
            display: block;
        }

        /* Alttaki Görsel için Sarı Çerçeve */
        .bottom-right-2::after {
            content: '';
            position: absolute;
            bottom: 0; /* Görselin tam alt kenarına hizala */
            left: -2px; /* Çok hafif sola kaydırdık */
            width: 100%; /* Görselin tam genişliği */
            height: 30px; /* Çizginin yukarı çıkma mesafesi */
            border-bottom: 4px solid #ffeb3b; /* Alt kenar */
            border-left: 4px solid #ffeb3b; /* Sol kenar */
            border-right: 4px solid #ffeb3b; /* Sağ kenar */
            border-top: none; /* Üst kenar açık */
            border-radius: 0 0 12px 12px; /* Alt kenarlarda oval şekil */
            z-index: 0;
        }

        .bottom-left-2 {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .bottom-left-2 .main-text-2 {
            display: flex;
            align-items: center;
            gap: 4px;
            font-size: 32px;
            font-weight: 700;
            color: #fff;
            line-height: 1;
        }

        .bottom-left-2 .main-text-2 img {
            max-height: 50px;
            height: auto;
        }

        .bottom-left-2 .yellow-line {
            width: 80%;
            height: 4px;
            background: #ffeb3b;
            border-radius: 2px;
            margin: 20px 0;
        }

        .bottom-left-2 .feature-button {
            display: flex;
            align-items: center;
            gap: 8px; /* İkon ve metin arasındaki boşluk azaltıldı */
            padding: 12px 24px;
            background: #ffeb3b;
            border-radius: 30px;
            font-weight: 700;
            font-size: 16px;
            color: #666;
            text-decoration: none;
            transition: all 0.3s;
            width: 100%; /* Butonların genişliğini tam kapla */
            justify-content: center; /* İçeriği ortala */
        }

        .bottom-left-2 .feature-button:hover {
            box-shadow: 0 0 20px #ffeb3b;
            color: #fff;
        }

        .bottom-left-2 .feature-button svg {
            width: 20px; /* İkon boyutları küçültüldü */
            height: 20px;
            stroke: #1a1a2e; /* Sadece stroke ile çizim */
            stroke-width: 2.5; /* Daha net görünüm için stroke kalınlığı artırıldı */
            fill: none; /* Fill kaldırıldı */
        }

        /* Footer Bölümü */
        footer {
            padding: 40px 20px;
            background: transparent;
            text-align: center; /* Tüm içeriği ortala */
            position: relative;
            z-index: 5;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .footer-logo img {
            max-width: 300px; /* Logo büyütüldü */
            height: auto;
        }

        .footer-copyright {
            font-size: 16px;
            color: #ccc;
        }

        .footer-copyright span {
            font-weight: bold;
            color: #ff147f; /* Tabisms pembe renk */
        }

        .social-icons {
            display: flex;
            gap: 20px; /* İkonlar arasında boşluk */
        }

        .social-icons a {
            display: inline-block;
            transition: all 0.3s;
        }

        .social-icons svg {
            width: 30px;
            height: 30px;
            fill: #fff; /* Varsayılan renk beyaz */
        }

        .social-icons a:hover svg.instagram {
            fill: #e1306c; /* Instagram mor/pembe tonu */
        }

        .social-icons a:hover svg.telegram {
            fill: #0088cc; /* Telegram mavi tonu */
        }

        .social-icons a:hover svg.twitter {
            fill: #1da1f2; /* Twitter açık mavi tonu */
        }

        /* Responsive Tasarım */
        @media (max-width: 768px) {
            .header-container {
                flex-direction: column;
                gap: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: center;
            }

            .login-hero-container {
                flex-direction: column;
            }

            .login-hero-left {
                flex-direction: column;
                align-items: center;
            }

            .promo-text-content, .promo-image {
                max-width: 100%;
            }

            .bottom-container {
                flex-direction: column;
            }

            .bottom-container-2 {
                flex-direction: column;
            }

            .bottom-left, .bottom-right {
                max-width: 100%;
            }

            .bottom-left-2, .bottom-right-2 {
                max-width: 100%;
            }

            .bottom-right .main-text {
                font-size: 24px;
            }

            .bottom-right .highlight-text {
                font-size: 20px;
            }

            .bottom-right .highlight-text img {
                max-height: 40px;
            }

            .bottom-left-2 .main-text-2 {
                font-size: 24px;
            }

            .bottom-left-2 .main-text-2 img {
                max-height: 40px;
            }

            .footer-logo img {
                max-width: 250px; /* Küçük ekranlarda logo biraz küçültüldü */
            }
        }

        @media (max-width: 480px) {
            .banner-slide img {
                max-width: 100%; /* Küçük ekranlarda taşmayı önlemek için */
            }

            .start-btn {
                bottom: 10px; /* Küçük ekranlarda butonun konumu */
                padding: 8px 20px; /* Küçük ekranlar için daha da küçültülmüş padding */
                font-size: 11px; /* Küçük ekranlar için daha da küçültülmüş font boyutu */
            }

            .banner-slide::after {
                height: 20px; /* Küçük ekranlarda yukarı çıkma mesafesini azalt */
            }

            .form-box::after {
                height: 40px; /* Küçük ekranlarda yukarı çıkma mesafesini azalt */
            }

            .bottom-left::after {
                height: 20px; /* Küçük ekranlarda yukarı çıkma mesafesini azalt */
            }

            .bottom-right-2::after {
                height: 20px; /* Küçük ekranlarda yukarı çıkma mesafesini azalt */
            }

            .logo img {
                max-width: 180px; /* Küçük ekranlarda logo boyutunu koruma */
            }

            .bottom-right .main-text {
                font-size: 20px;
            }

            .bottom-right .highlight-text {
                font-size: 18px;
            }

            .bottom-right .highlight-text img {
                max-height: 36px;
            }

            .bottom-right .feature-item {
                font-size: 14px;
            }

            .bottom-left-2 .main-text-2 {
                font-size: 20px;
            }

            .bottom-left-2 .main-text-2 img {
                max-height: 36px;
            }

            .bottom-left-2 .feature-button {
                font-size: 14px;
                padding: 10px 20px;
            }

            .footer-logo img {
                max-width: 200px; /* Çok küçük ekranlarda logo daha da küçültüldü */
            }

            .footer-copyright {
                font-size: 14px;
            }

            .social-icons svg {
                width: 24px;
                height: 24px;
            }
        }
    </style>
</head>
<body>

    <!-- 🌌 Dekoratif Arka Plan Objeleri -->
    <div class="bg-objects">
        <div class="planet purple"></div>
        <div class="planet dog-planet"></div>
    </div>

    <!-- 🧭 HEADER -->
    <header class="site-header">
        <div class="header-container">
            <div class="logo">
                <a href="index.php">
                    <img src="images/logo.png" alt="Tabisms Logo">
                </a>
            </div>
            <nav class="nav-buttons">
                <a href="girisyap.php" class="btn green">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1a1a2e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M16 20h4a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-4"/>
                        <path d="M8 20H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h4"/>
                        <path d="M9 14l3-3-3-3"/>
                        <path d="M15 14l-3-3 3-3"/>
                    </svg>
                    Giriş Yap
                </a>
                <a href="servis.php" class="btn pink">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="3" y1="6" x2="21" y2="6"/>
                        <line x1="3" y1="12" x2="21" y2="12"/>
                        <line x1="3" y1="18" x2="21" y2="18"/>
                    </svg>
                    Servis Listesi
                </a>
                <a href="index.php" class="btn yellow">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1a1a2e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                        <circle cx="9" cy="7" r="4"/>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                    </svg>
                    Kayıt Ol
                </a>
            </nav>
        </div>
    </header>

    <!-- 🚀 GİRİŞ SAYFASI BANNER BAŞLANGICI -->
    <main class="login-hero-section">
        <div class="login-hero-container">
            <!-- 🎯 Sol Tanıtım Kutusu -->
            <div class="login-hero-left">
                <div class="promo-text-content">
                    <!-- Banner Carousel -->
                    <div class="banner-carousel">
                        <div class="banner-container" id="bannerContainer">
                            <div class="banner-slide active">
                                <img src="imagesss/banner.png" alt="Tabisms Banner">
                            </div>
                            <div class="banner-slide">
                                <img src="imagesss/banner2.png" alt="Tabisms Banner 2">
                            </div>
                            <div class="banner-slide">
                                <img src="imagesss/banner3.png" alt="Tabisms Banner 3">
                            </div>
                        </div>
                        <!-- Sağ/Sol Ok Butonları -->
                        <button class="carousel-nav prev-btn" onclick="prevSlide()">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M15 18l-6-6 6-6"/>
                            </svg>
                        </button>
                        <button class="carousel-nav next-btn" onclick="nextSlide()">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M9 18l6-6-6-6"/>
                            </svg>
                        </button>
                        <!-- "Haydi Başlayalım" butonu -->
                        <a href="index.php" style="text-decoration: none;">
                            <button class="start-btn">Haydi Başlayalım</button>
                        </a>
                    </div>
                    <div class="promo-stats">
                        <div>
                            <svg width="32" height="32" fill="none" stroke="#00ff7f" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M20 12c0 4.418-4.03 8-9 8s-9-3.582-9-8 4.03-8 9-8 9 3.582 9 8z"/><path d="M8 14s1 2 4 2 4-2 4-2"/><circle cx="9" cy="10" r="1"/><circle cx="15" cy="10" r="1"/></svg><br>
                            <strong>+8.260</strong><br>
                            <span>Mutlu Müşteri</span>
                        </div>
                        <div>
                            <svg width="32" height="32" fill="none" stroke="#00ff7f" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M3 3h18v18H3z"/><path d="M8 7h8M8 11h8M8 15h6"/></svg><br>
                            <strong>+8.260</strong><br>
                            <span>Başarılı Sipariş</span>
                        </div>
                    </div>
                    <p class="promo-text">
                        Hemen kayıt olarak sipariş verebilir, hesabınızın etkileşimini 
                        <span style="color:#ff147f; font-weight: bold;">Tabisms</span> ile hızlıca yükseltebilirsiniz.
                    </p>
                </div>
                <div class="promo-image">
                    <!-- Boş kapsayıcı -->
                </div>
            </div>

            <!-- 🔐 Sağ Kayıt Formu -->
            <div class="login-hero-right">
                <div class="form-box">
                    <h2 class="form-title">Kayıt Ol</h2>
                    <!-- PHP Hata Mesajı için Yer Tutucu -->
                    <p class="error-message" style="display: none;">Lütfen tüm alanları doldurun.</p>
                    <form action="#" method="POST" class="register-form">
                        <div class="input-group">
                            <svg class="input-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                                <circle cx="12" cy="7" r="4"/>
                            </svg>
                            <input type="text" name="ad_soyad" placeholder="Ad ve Soyad" required>
                        </div>
                        <div class="input-group">
                            <svg class="input-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                                <circle cx="12" cy="7" r="4"/>
                            </svg>
                            <input type="text" name="kullanici_adi" placeholder="Kullanıcı Adı" required>
                        </div>
                        <div class="input-group">
                            <svg class="input-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                                <polyline points="22,6 12,13 2,6"/>
                            </svg>
                            <input type="email" name="email" placeholder="E-posta Adresi" required>
                        </div>
                        <div class="input-group">
                            <svg class="input-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                            </svg>
                            <input type="tel" name="telefon" placeholder="Telefon Numarası" required>
                        </div>
                        <div class="input-group">
                            <svg class="input-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                            <input type="password" name="parola" placeholder="Parola" required>
                        </div>
                        <div class="input-group">
                            <svg class="input-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                            <input type="password" name="parola_tekrar" placeholder="Parola Tekrar" required>
                        </div>
                        <label class="checkbox-label">
                            <input type="checkbox" required>
                            <span><a href="uyelik-sozlesmesi.php">Üyelik sözleşmesini</a> okudum ve kabul ediyorum.</span>
                        </label>
                        <button type="submit" class="submit-button orange">➜ Kayıt Ol</button>
                        <p class="login-prompt">Zaten hesabınız var mı?</p>
                        <button type="button" class="submit-button green" onclick="window.location.href='girisyap.php'">➜ Giriş Yap</button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <!-- 🌟 İlk Alt Bölüm -->
    <section class="bottom-section">
        <div class="bottom-container">
            <!-- Sol Tarafta Görsel -->
            <div class="bottom-left">
                <img src="imagesss/gorsel1.png" alt="Görsel 1">
            </div>

            <!-- Sağ Tarafta Metin ve Öğeler -->
            <div class="bottom-right">
                <h2 class="main-text">ARTIK SMS TEK BİR PANELDE</h2>
                <div class="highlight-text">
                    <img src="images/logo.png" alt="Tabisms Logo">
                    <span> ile Yollayabilirsin!</span>
                </div>
                <div class="green-line"></div>
                <div class="features">
                    <div class="feature-item">
                        <div class="check-circle">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                <path d="M20 6L9 17l-5-5"/>
                            </svg>
                        </div>
                        İadeli sms
                    </div>
                    <div class="feature-item">
                        <div class="check-circle">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                <path d="M20 6L9 17l-5-5"/>
                            </svg>
                        </div>
                        Hızlı teslimat
                    </div>
                    <div class="feature-item">
                        <div class="check-circle">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                <path d="M20 6L9 17l-5-5"/>
                            </svg>
                        </div>
                        %100 müşteri memnuniyeti
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 🌟 İkinci Alt Bölüm -->
    <section class="bottom-section-2">
        <div class="bottom-container-2">
            <!-- Sol Tarafta Metin ve Öğeler -->
            <div class="bottom-left-2">
                <div class="main-text-2">
                    <span>Peki Neden</span>
                    <img src="images/logo.png" alt="Tabisms Logo">
                </div>
                <div class="yellow-line"></div>
                <a href="#" class="feature-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1a1a2e" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="5" x2="12" y2="19"/>
                        <line x1="5" y1="12" x2="19" y2="12"/>
                    </svg>
                    Tamamen uygun fiyatlar
                </a>
                <a href="#" class="feature-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1a1a2e" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                    </svg>
                    7/24 destek
                </a>
                <a href="#" class="feature-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1a1a2e" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2a10 10 0 0 0-7.07 2.93 10 10 0 0 0 0 14.14A10 10 0 0 0 12 22a10 10 0 0 0 7.07-2.93 10 10 0 0 0 0-14.14A10 10 0 0 0 12 2zm1 15l-2-2 2-2m-2-2l2-2-2-2"/>
                    </svg>
                    Tam otomatik panel
                </a>
                <a href="#" class="feature-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1a1a2e" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20 6L9 17l-5-5"/>
                    </svg>
                    Kullanımı kolay arayüz
                </a>
            </div>

            <!-- Sağ Tarafta Görsel -->
            <div class="bottom-right-2">
                <img src="imagesss/gorsel2.png" alt="Görsel 2">
            </div>
        </div>
    </section>

    <!-- 🖼️ Footer Bölümü -->
    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                <img src="images/logo.png" alt="Tabisms Logo">
            </div>
            <p class="footer-copyright">
                Copyright 2025 <span>Tabisms</span> Tüm Hakları Saklıdır.
            </p>
            <div class="social-icons">
                <a href="https://instagram.com" target="_blank">
                    <svg class="instagram" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M12 2c2.717 0 3.056.01 4.122.06 1.065.05 1.79.218 2.423.465.633.247 1.176.584 1.714 1.122.538.538.875 1.081 1.122 1.714.247.633.415 1.358.465 2.423.05 1.066.06 1.405.06 4.122s-.01 3.056-.06 4.122c-.05 1.065-.218 1.79-.465 2.423-.247.633-.584 1.176-1.122 1.714-.538.538-1.081.875-1.714 1.122-.633.247-1.358.415-2.423.465-1.066.05-1.405.06-4.122.06s-3.056-.01-4.122-.06c-1.065-.05-1.79-.218-2.423-.465-.633-.247-1.176-.584-1.714-1.122-.538-.538-.875-1.081-1.122-1.714-.247-.633-.415-1.358-.465-2.423-.05-1.066-.06-1.405-.06-4.122s.01-3.056.06-4.122c.05-1.065.218-1.79.465-2.423.247-.633.584-1.176 1.122-1.714.538-.538 1.081-.875 1.714-1.122.633-.247 1.358-.415 2.423-.465 1.066-.05 1.405-.06 4.122-.06zm0-2c-2.75 0-3.111.012-4.192.062-1.082.05-1.953.24-2.65.513-.697.273-1.294.644-1.885 1.235-.591.591-.962 1.188-1.235 1.885-.273.697-.463 1.568-.513 2.65-.05 1.081-.062 1.442-.062 4.192s.012 3.111.062 4.192c.05 1.082.24 1.953.513 2.65.273.697.644 1.294 1.235 1.885.591.591 1.188.962 1.885 1.235.697.273 1.568.463 2.65.513 1.081.05 1.442.062 4.192.062s3.111-.012 4.192-.062c1.082-.05 1.953-.24 2.65-.513.697-.273 1.294-.644 1.885-1.235.591-.591.962-1.188 1.235-1.885.273-.697.463-1.568.513-2.65.05-1.081.062-1.442.062-4.192s-.012-3.111-.062-4.192c-.05-1.082-.24-1.953-.513-2.65-.273-.697-.644-1.294-1.235-1.885-.591-.591-1.188-.962-1.885-1.235-.697-.273-1.568-.463-2.65-.513-1.081-.05-1.442-.062-4.192-.062zm0 5.838c-3.405 0-6.162 2.757-6.162 6.162s2.757 6.162 6.162 6.162 6.162-2.757 6.162-6.162-2.757-6.162-6.162-6.162zm0 10.162c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.441s.645 1.441 1.441 1.441 1.441-.645 1.441-1.441-.645-1.441-1.441-1.441z"/>
                    </svg>
                </a>
                <a href="https://telegram.org" target="_blank">
                    <svg class="telegram" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.69.93-1.1.58-.65-.56-1.65-1.75-2.27-2.27-.28-.23-.45-.45-.16-.93l1.13-3.43c.39-1.18.17-1.62-.88-.94L9.5 11.53c-.63.36-1.22.42-1.54.07l-1.63-1.2c-.66-.49-.34-.94.27-1.09 1.94-.49 7.63-2.92 8.54-3.31.43-.18.81.02.9.47z"/>
                    </svg>
                </a>
                <a href="https://twitter.com" target="_blank">
                    <svg class="twitter" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/>
                    </svg>
                </a>
            </div>
        </div>
    </footer>

    <!-- JavaScript for Carousel Navigation and Auto-Sliding -->
    <script>
        let currentSlide = 0;
        const totalSlides = 3; // Üç banner var
        const slides = document.querySelectorAll('.banner-slide');

        function showSlide(index) {
            // Döngüsel geçiş
            if (index >= totalSlides) {
                currentSlide = 0;
            } else if (index < 0) {
                currentSlide = totalSlides - 1;
            } else {
                currentSlide = index;
            }

            // Tüm slaytları gizle
            slides.forEach(slide => {
                slide.classList.remove('active');
            });

            // Sadece aktif slaytı göster
            slides[currentSlide].classList.add('active');
        }

        function nextSlide() {
            showSlide(currentSlide + 1);
        }

        function prevSlide() {
            showSlide(currentSlide - 1);
        }

        // Otomatik geçiş (her 6 saniyede bir)
        setInterval(() => {
            nextSlide();
        }, 6000);

        // İlk slaytı göster
        showSlide(currentSlide);
    </script>
</body>
</html>