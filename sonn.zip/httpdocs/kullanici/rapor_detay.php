<?php
/*
require_once "header.php";
require_once "left.php";

$id = $_GET["id"];

?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Raporlar</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Gönderilen Numaralar</h4>
                            <hr>

                            <?php
                            $kull = $pdo->prepare("SELECT * FROM gonderilen_numaralar WHERE kul_id=:kul_id and mesaj_id=:mesaj_id");
                            $kull->execute(array(":kul_id"=>$_SESSION["kullanici_id"],":mesaj_id"=>$id));
                            if($kull->rowCount() ==0 ) {
                              uyari("Kayıtlı Numara Bulunamadı");
                            } else {
                              ?>
                              <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                  <thead>
                                  <tr>
                                      <th>ID</th>
                                      <th> Tel</th>
                                  </tr>
                                  </thead>

                                  <tbody>
                                    <?php
                                      while(false !== $k = $kull->fetch(PDO::FETCH_OBJ)) {
                                        ?>
                                        <tr>
                                            <td><?=$k->id;?></td>
                                            <td><?=$k->no;?></td>
                                    </tr>
                                        <?php
                                      }
                                    ?>
                                  </tbody>
                              </table>
                              <?php

                            }

                             ?>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->




        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
*/
