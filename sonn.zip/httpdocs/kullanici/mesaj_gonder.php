<?php

require_once "header.php";
require_once "left.php";
require_once "../functions.php";

$baki = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
$baki->execute(array(":id"=>$_SESSION["kullanici_id"]));
$bakiye = $baki->fetch(PDO::FETCH_OBJ);
$_SESSION["bakiye"] = $bakiye->bakiye;
$_SESSION["baslik"] = $bakiye->baslik;
?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <form method="post" action="mesaj_gonder_post.php">
                                <div class="form-group">
                                    <label>Mesaj Metni</label>
                                    <textarea name="icerik" id="icerik" maxlength="159" autofocus class="form-control" rows="6" cols="80"></textarea>
                                    <div id="the-count">
                                        <span id="current">0</span>
                                        <span id="maximum">/ 159</span>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <p class="warning-text">* Gönderilen mesaj metninin karakter sayısı 159'u geçemez</p>
                                </div>
                                <div class="form-group">
                                    <label>Gönderilecek Numaralar</label>
                                    <textarea name="numaralar" class="form-control" rows="8" cols="80" required></textarea>
                                </div>
                                <div class="form-group">
                                    <div class="button-container">
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">
                                            Gönder
                                        </button>
                                    </div>
                                </div>
                                <div class="form-group" style="visibility:hidden;">
                                    <label>SMS Başlığı</label>
                                    <select name="ctl00_ortaalan_orjinator" readonly id="ctl00_ortaalan_orjinator" class="form-control">
                                        <option>Otomatik</option>
                                    </select>
                                </div>
                                <div class="form-group" style="visibility:hidden;">
                                    <select name="ctl00_ortaalan_mesajtipi" id="ctl00_ortaalan_mesajtipi" onchange="textCounter(this.form.karakter,this.form.smssayi);" class="form-control">
                                        <option value="Normal">Normal SMS</option>
                                        <option value="Türkçe">Türkçe SMS</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="card-heading p-4">
                                <div class="mini-stat-icon float-right">
                                    <i class="mdi mdi-cellphone-sound bg-primary text-white"></i>
                                </div>
                                <div>
                                    <?php
                                    $baki = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
                                    $baki->execute(array(":id"=>$_SESSION["kullanici_id"]));
                                    $bakiye = $baki->fetch(PDO::FETCH_OBJ);
                                    ?>
                                    <h5 class="font-16">Mevcut Bakiyeniz</h5>
                                </div>
                                <h3 class="mt-4"><?=$bakiye->bakiye;?></h3>
                                <div class="progress mt-4" style="height: 4px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="alert alert-success mb-0" role="alert">
                                <h4 class="alert-heading mt-0 font-18">Bilgilendirme!</h4>
                                <p>* Yanlış Girilen Telefon Numaralarını Sistem Kabul Etmemektedir</p>
                                <p>* (544) şeklinde başlayan numaralar kabul edilmemektedir.</p>
                                <p>* Telefon numaralarını alt alta yazıp kaydedebilirsiniz.</p>
                            </div>
                        </div>
                    </div>
                </div><!-- end col -->
            </div> <!-- end row -->
        </div>
        <!-- container-fluid -->
    </div>
</div>

<?php
require_once "footer.php";
?>

<!-- Tabisms Teması için Özel Stil -->
<style>
    .content-page {
        background: transparent;
    }

    .content {
        padding-top: 10px; /* Üstteki boşluğu azalttık */
        position: relative;
        z-index: 5;
    }

    .container-fluid {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    .card {
        background: #2a2a4a;
        border: none;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
        position: relative;
        margin-bottom: 30px;
    }

    .card-body {
        padding: 20px; /* Üst ve alt boşlukları azalttık */
    }

    .card-heading {
        position: relative;
    }

    .mini-stat-icon {
        position: absolute;
        top: 20px;
        right: 20px;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .mini-stat-icon i {
        font-size: 20px;
    }

    .bg-primary {
        background: #ff147f !important;
    }

    .bg-success {
        background: #00ff7f !important;
    }

    .bg-warning {
        background: #ffeb3b !important;
    }

    .text-white {
        color: #fff !important;
    }

    .font-16 {
        font-size: 16px;
        color: #ccc;
    }

    h3 {
        font-size: 32px;
        color: #fff;
        margin: 20px 0;
    }

    .progress {
        height: 4px;
        background: #3a3a5a;
        border-radius: 2px;
        margin-top: 20px;
    }

    .progress-bar {
        border-radius: 2px;
    }

    .header-title {
        font-size: 24px;
        color: #fff;
        margin-bottom: 20px;
    }

    hr {
        border-top: 1px solid #3a3a5a;
    }

    .form-group label {
        color: #ccc;
        font-size: 14px;
    }

    .form-group textarea {
        background: #3a3a5a;
        border: none;
        border-radius: 10px;
        color: #fff;
        font-size: 14px;
        padding: 12px;
        resize: vertical; /* Kullanıcının yalnızca dikey olarak boyutlandırmasına izin verir */
    }

    .form-group textarea:focus {
        outline: none;
        box-shadow: 0 0 10px rgba(255, 20, 127, 0.3);
    }

    .form-group select {
        background: #3a3a5a;
        border: none;
        border-radius: 10px;
        color: #fff;
        font-size: 14px;
        padding: 12px;
    }

    .form-group select:focus {
        outline: none;
        box-shadow: 0 0 10px rgba(255, 20, 127, 0.3);
    }

    #the-count {
        display: flex;
        justify-content: flex-end;
        gap: 5px;
        margin-top: 10px;
        font-size: 14px;
        color: #ccc;
    }

    #the-count #current {
        color: #ff147f;
    }

    #the-count #maximum {
        color: #ccc;
    }

    .button-container {
        text-align: center; /* Gönder butonunu ortala */
    }

    .btn-primary {
        background: #ff147f;
        border: none;
        border-radius: 30px;
        padding: 10px 20px;
        font-weight: 600;
        font-size: 14px;
        color: #fff;
        transition: all 0.3s;
    }

    .btn-primary:hover {
        background: #ff4081;
        box-shadow: 0 0 15px rgba(255, 20, 127, 0.5);
    }

    .alert {
        background: #00ff7f;
        color: #1a1a2e;
        padding: 10px;
        border-radius: 10px;
        font-size: 14px;
    }

    .alert.alert-info {
        background: #ff147f;
        color: #fff;
    }

    .alert.alert-success {
        background: #00ff7f;
        color: #1a1a2e;
    }

    .alert-heading {
        font-size: 18px;
        color: inherit;
    }

    .alert p {
        color: inherit;
        margin: 5px 0;
    }

    .warning-text {
        color: #ccc;
        font-size: 14px;
        margin: 0;
    }

    /* Responsive Tasarım */
    @media (max-width: 768px) {
        .content {
            padding-top: 5px;
        }

        .card-body {
            padding: 15px;
        }

        h3 {
            font-size: 24px;
        }

        .font-16 {
            font-size: 14px;
        }

        .form-group textarea,
        .form-group select {
            font-size: 12px;
            padding: 10px;
        }

        .btn-primary {
            font-size: 12px;
            padding: 8px 16px;
        }

        .alert {
            font-size: 12px;
        }

        .alert-heading {
            font-size: 16px;
        }

        .warning-text {
            font-size: 12px;
        }

        #the-count {
            font-size: 12px;
        }
    }
</style>