<?php


require_once "header.php";
require_once "left.php";
require_once "../functions.php";

// kara listeyi al
$kara_numaralar =array();
$kara_liste = $pdo->query("SELECT * FROM kara_liste");
if($kara_liste->rowCount()>0) {
  while(false !== $kara =$kara_liste->fetch(PDO::FETCH_OBJ)) {
     array_push($kara_numaralar,$kara->numara);
  }
}

$baki = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
$baki->execute(array(":id"=>$_SESSION["kullanici_id"]));
$bakiye = $baki->fetch(PDO::FETCH_OBJ);

?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">SMS Gönder</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <!-- end page-title -->
    <?php

  $sms_gonderim_sekli =$pdo->query("SELECT * FROM yonetici WHERE id=1");
  $ss = $sms_gonderim_sekli->fetch(PDO::FETCH_OBJ);
  $sms_sekli = $ss->sms_gonderim_sekli;

  if(isset($_POST)) {


          $mesaj = trim($_POST["icerik"]);
          $numaralar  = trim($_POST["numaralar"]);


          $ilave = str_replace(',', ' , ', $_POST["numaralar"]);
          $ilave = str_replace(' ', '', $_POST["numaralar"]);
          // ilave edilecek numaralar ayrıştırılıyor.
          $ilaveler = [];
          if (preg_match_all("/(?:^|[^\d])(\d{10,12})(?:[^\d]|$)/", $ilave, $matches)) {
            $ilaveler = $matches[ 1 ];
          }
          $ilaveler = array_unique($ilaveler);
          $dusulecek_bakiye = count($ilaveler);


          // tel fonkisyonunu $ilaveler dizisine uygula
          $ilaveler = array_map("tel",$ilaveler);
          $ilaveler = array_unique($ilaveler);


          if($mesaj =="" || $numaralar =="") {
            uyari("Boş Alan Bırakmayınız");
          } else if(count($ilaveler) > $bakiye->bakiye) {
            uyari("Bakiyeniz Yetersiz");
          }else if(count($ilaveler) <1) {
            uyari("Gönderilecek Numaraları Kontrol Ediniz");
          }else if(count($ilaveler) > 100000) {
            uyari("100.000 Üzeri Gönderim Yapamazsınız");
          }else {
            // Mesaj gönderim seçeneğini konrol et.  Otomatik ise api ile gönderilsin manuelse sadece db ye kayıt yapsın o kadar.
            $sorgu = $pdo->prepare("INSERT INTO gonderilen_mesajlar VALUES(NULL,
            :kul_id,
            :baslik,
            :icerik,
            :sms_gonderim_sekli,
            :gonderilen,
            :gonderilen_filtresiz,
            '0',
            '0',
            '0',
            :eklenme_tarihi,
            '',
            '0',
            ''
          )");

            if($sms_sekli ==0) {  // Manuel Gönder
              $sorgu->bindValue(":sms_gonderim_sekli",0,PDO::PARAM_INT);
            } else if($sms_sekli ==1) { // Otomatik Gönder
              $sorgu->bindValue(":sms_gonderim_sekli",1,PDO::PARAM_INT);
            }
            $sorgu->bindValue(":baslik",$baslik->baslik,PDO::PARAM_STR);
            $sorgu->bindValue(":gonderilen_filtresiz",$dusulecek_bakiye,PDO::PARAM_INT);
            $sorgu->bindValue(":gonderilen",0,PDO::PARAM_STR);
            $sorgu->bindValue(":kul_id",$_SESSION["kullanici_id"],PDO::PARAM_INT);
            $sorgu->bindValue(":eklenme_tarihi",time(),PDO::PARAM_INT);
            $sorgu->bindValue(":icerik",$mesaj,PDO::PARAM_STR);
            $sorgu->execute();
            if($sorgu->rowCount()>0) {
              bilgi("Mesajınız Başarıyla Gönderildi.");
              $son_id = $pdo->lastInsertId();
              // Bakiyeden Düş
              $dus = $pdo->prepare("UPDATE kullanicilar SET bakiye = bakiye - :sayi WHERE id=:id");
              $dus->execute(array(":sayi"=>$dusulecek_bakiye,":id"=>$_SESSION["kullanici_id"]));


              $m_kaydet = $pdo->prepare("INSERT INTO gonderilen_numaralar VALUES(NULL,:kul_id,:son_id,:tel)");
              $numaralar ="";
              $son_dizi = array_diff($ilaveler , $kara_numaralar);
              foreach ($son_dizi as $key ) {
                  $m_kaydet->bindValue(":kul_id",$_SESSION["kullanici_id"],PDO::PARAM_INT);
                  $m_kaydet->bindValue(":son_id",$son_id,PDO::PARAM_INT);
                  $m_kaydet->bindValue(":tel",tel($key),PDO::PARAM_INT);
                  $m_kaydet->execute();
                //  echo $key."<br>";
                  //$m_kaydet->execute(array($_SESSION["kullanici_id"],$son_id,tel($key)));
                  $numaralar =$numaralar.",".$key;

              }

              // Kara listedeki  noları sil
              // $silinecekler = $pdo->prepare("SELECT gon.id as aydi FROM gonderilen_numaralar as gon,kara_liste as kara WHERE gon.no = kara.numara and mesaj_id=:son_id and  kul_id=:kul_id");
              // $silinecekler->execute(array(":son_id"=>$son_id,":kul_id"=>$_SESSION["kullanici_id"]));
              // if($silinecekler->rowCount()>0) {
              //   while(false !== $si = $silinecekler->fetch(PDO::FETCH_OBJ)) {
              //     $delete = $pdo->prepare("DELETE FROM gonderilen_numaralar WHERE id=:aydi");
              //     $delete->execute(array(":aydi"=>$si->aydi));
              //   }
              // }

              // filtresiz gonderim saysını güncelle
              $filtresiz = $pdo->prepare("UPDATE gonderilen_mesajlar SET gonderilen=:sayi WHERE id=:id");
              $filtresiz->execute(array(":id"=>$son_id,":sayi"=>count($son_dizi)));

            $numaralar = substr($numaralar,1);
            // Gönderim Otomatik ise SMS Gönder
            if($sms_sekli ==1) {
              $data = array(
                  "users" =>array(
                      "username"=>"evosms",
                      "password"=>"kt7735"
                  ),
                  "DataCoding"=>"Default",
                  "Header"=>array(
                    "Sender"=>$baslik->baslik
                  ),
                  "Message" =>$mesaj,
                  "Number" =>$numaralar,
                  "Blacklist"=>"false"
              );

              $data_string = json_encode($data);
              $header_type =array('Content-Type: application/json');
              $ch = curl_init();
              curl_setopt($ch, CURLOPT_URL,"https://api.vuxpanel.com/Json/Submit");
              curl_setopt($ch, CURLOPT_POST, 1);
              curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
              curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,0);
              curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
              curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
              curl_setopt($ch, CURLOPT_HTTPHEADER,$header_type);
              curl_setopt($ch, CURLOPT_HEADER, 0);
              curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
              curl_setopt($ch, CURLOPT_TIMEOUT, 120);
                $result = curl_exec($ch);

                $obj = json_decode($result);
                $durum = $obj->Response->Status->Code;

                $ggg  = $pdo->prepare("UPDATE gonderilen_mesajlar SET status_code=:status WHERE id=:id");
                $ggg->execute(array(":status"=>$durum,":id"=>$son_id));

                if($durum==0 || $durum =="0") {
                  //bilgi("Mesaj Gönderildi");
                  $api_donen_key =  $obj->Response->MessageId;

                  $gg = $pdo->prepare("UPDATE gonderilen_mesajlar SET api_donen_key=:key,durum=1 WHERE id=:id");
                  $gg->execute(array(":key"=>$api_donen_key,":id"=>$son_id));
                  if($gg->rowCount()==0) {
                    uyari("Olmadı");
                  }
                }
            }
            }
          }


  }

?>
<div class="row">
  <div class="col-md-6">
    <div class="card m-b-30">
      <div class="card-body">
        <div class="card-heading p-4">
            <div class="mini-stat-icon float-right">
                <i class="mdi mdi-cellphone-sound bg-primary  text-white"></i>
            </div>
            <div>
              <?php
                $baki = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
                $baki->execute(array(":id"=>$_SESSION["kullanici_id"]));
                $bakiye = $baki->fetch(PDO::FETCH_OBJ);
               ?>
            <h5 class="font-16">Mevcut Bakiyeniz</h5>
            </div>
            <h3 class="mt-4"><?=$bakiye->bakiye;?></h3>
            <div class="progress mt-4" style="height: 4px;">
                <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
      </div>
      </div>
    </div>
  </div>
  <div class="col-sm-6 col-xl-6">
      <div class="card">
          <div class="card-heading p-4">
              <div class="mini-stat-icon float-right">
                  <i class="mdi mdi-checkbox-marked-circle-outline bg-success text-white"></i>
              </div>
              <div>
              <h5 class="font-16">Gönderilen SMS</h5>
              </div>
              <h3 class="mt-4"><br><?=$dusulecek_bakiye;?></h3>
              <div class="progress mt-4" style="height: 4px;">
                    <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="88" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
        </div>
      </div>
  </div>
</div>
