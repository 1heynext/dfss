<?php
session_start();
require_once "../config.php";
require_once "../functions.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $kul_adi = trim($_POST["kul_adi"] ?? '');
    $parola  = trim($_POST["parola"] ?? '');

    if ($kul_adi === "" || $parola === "") {
        header("Location: ../girisyap.php?error=empty");
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM kullanicilar WHERE kul_adi = :kul_adi AND parola_md5 = :parola");
    $stmt->bindValue(":kul_adi", $kul_adi, PDO::PARAM_STR);
    $stmt->bindValue(":parola", md5($parola), PDO::PARAM_STR);
    $stmt->execute();

    if ($stmt->rowCount() === 1) {
        $user = $stmt->fetch(PDO::FETCH_OBJ);
        $_SESSION["kullanici_kul_adi"] = $user->kul_adi;
        $_SESSION["kullanici_id"] = $user->id;
        $_SESSION["login"] = true;
        header("Location: index.php"); // Or kullanici/index.php
        exit;
    } else {
        header("Location: ../girisyap.php?error=invalid");
        exit;
    }
} else {
    header("Location: ../girisyap.php");
    exit;
}
