<?php

require_once "header.php";
require_once "left.php";

?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <h4 class="mt-0 header-title">Kayıtlı Mesajlar</h4>
                            <hr>
                            <?php
                            $kull = $pdo->prepare("SELECT * FROM gonderilen_mesajlar WHERE kul_id=:kul_id ORDER BY id DESC");
                            $kull->execute(array(":kul_id"=>$_SESSION["kullanici_id"]));
                            if($kull->rowCount() == 0) {
                                uyari("Kayıtlı Mesaj Bulunamadı");
                            } else {
                            ?>
                            <div class="table-responsive">
                                <table id="datatable" class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>İçerik</th>
                                            <th>İşlem Zamanı</th>
                                            <th>Durum</th>
                                            <th>Gönderilen</th>
                                            <th>İletilen</th>
                                            <th>İletilmeyen</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        while(false !== $k = $kull->fetch(PDO::FETCH_OBJ)) {
                                        ?>
                                        <tr>
                                            <td><?=$k->id;?></td>
                                            <td><?=$k->icerik;?></td>
                                            <td><?=date("d.m.Y / H:i", $k->eklenme_tarihi);?></td>
                                            <td><?php if($k->durum == 0) { echo "Beklemede";} else { echo "Gönderildi";} ?></td>
                                            <td><?=$k->gonderilen_filtresiz;?></td>
                                            <td><?=$k->iletilen;?></td>
                                            <td><?=$k->hatali;?></td>
                                        </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
        </div>
        <!-- container-fluid -->
    </div>
</div>

<?php
require_once "footer.php";
?>

<!-- Tabisms Teması için Özel Stil -->
<style>
    .content-page {
        background: transparent;
    }

    .content {
        padding-top: 30px;
        position: relative;
        z-index: 5;
    }

    .container-fluid {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    .card {
        background: #2a2a4a;
        border: none;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
        position: relative;
        margin-bottom: 30px;
    }

    .card-body {
        padding: 30px;
    }

    .header-title {
        font-size: 24px;
        color: #fff;
        margin-bottom: 20px;
    }

    hr {
        border-top: 1px solid #3a3a5a;
    }

    .alert {
        background: #ff147f;
        color: #fff;
        padding: 10px;
        border-radius: 10px;
        text-align: center;
        font-size: 14px;
    }

    .table-responsive {
        overflow-x: auto;
    }

    .table {
        background: #2a2a4a;
        color: #fff;
        border-color: #3a3a5a;
    }

    .table th {
        background: #3a3a5a;
        color: #ccc;
        border-color: #3a3a5a;
        font-size: 14px;
        padding: 12px;
        text-align: center;
    }

    .table td {
        background: #2a2a4a;
        color: #fff;
        border-color: #3a3a5a;
        font-size: 14px;
        padding: 12px;
        text-align: center;
    }

    .table tbody tr:hover {
        background: #3a3a5a;
    }

    /* Responsive Tasarım */
    @media (max-width: 768px) {
        .content {
            padding-top: 20px;
        }

        .card-body {
            padding: 20px;
        }

        .header-title {
            font-size: 20px;
        }

        .table th,
        .table td {
            font-size: 12px;
            padding: 10px;
        }

        .alert {
            font-size: 12px;
        }
    }
</style>