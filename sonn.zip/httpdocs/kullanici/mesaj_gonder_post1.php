<?php
require_once "header.php";
require_once "../functions.php";

// Kara listeyi al
$kara_numaralar = array();
$kara_liste = $pdo->query("SELECT * FROM kara_liste");
if ($kara_liste->rowCount() > 0) {
    while (false !== $kara = $kara_liste->fetch(PDO::FETCH_OBJ)) {
        array_push($kara_numaralar, $kara->numara);
    }
}

?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <?php
            $sms_gonderim_sekli = $pdo->query("SELECT * FROM yonetici WHERE id=1");
            $ss = $sms_gonderim_sekli->fetch(PDO::FETCH_OBJ);
            $sms_sekli = $ss->sms_gonderim_sekli;

            if (isset($_POST)) {
                $mesaj = trim($_POST["icerik"]);
                $numaralar = trim($_POST["numaralar"]);

                $ilave = str_replace(',', ' , ', $_POST["numaralar"]);
                $ilave = str_replace(' ', '', $_POST["numaralar"]);
                // Ilave edilecek numaralar ayrıştırılıyor.
                $ilaveler = [];
                if (preg_match_all("/(?:^|[^\d])(\d{10,12})(?:[^\d]|$)/", $ilave, $matches)) {
                    $ilaveler = $matches[1];
                }
                $ilaveler = array_unique($ilaveler);
                $dusulecek_bakiye = count($ilaveler);

                // Tel fonksiyonunu $ilaveler dizisine uygula
                $ilaveler = array_map("tel", $ilaveler);
                $ilaveler = array_unique($ilaveler);

                if ($mesaj == "" || $numaralar == "") {
                    uyari("Boş Alan Bırakmayınız");
                } else if (count($ilaveler) < 1) {
                    uyari("Gönderilecek Numaraları Kontrol Ediniz");
                } else if (count($ilaveler) > 5000) {
                    // 5k üzeri ise parçalayarak kaydet
                    $parca = ceil(count($ilaveler) / 5000);
                    $basla = 0;
                    for ($i = 1; $i <= $parca; $i++) {
                        $sorgu = $pdo->prepare("INSERT INTO gonderilen_mesajlar VALUES(NULL,
                            :kul_id,
                            :baslik,
                            :icerik,
                            :sms_gonderim_sekli,
                            :gonderilen,
                            '0',
                            '0',
                            '0',
                            :eklenme_tarihi,
                            '',
                            '0'
                        )");

                        if ($sms_sekli == 0) { // Manuel Gönder
                            $sorgu->bindValue(":sms_gonderim_sekli", 0, PDO::PARAM_INT);
                        } else if ($sms_sekli == 1) { // Otomatik Gönder
                            $sorgu->bindValue(":sms_gonderim_sekli", 1, PDO::PARAM_INT);
                        }
                        $sorgu->bindValue(":baslik", $baslik->baslik, PDO::PARAM_STR);
                        $sorgu->bindValue(":gonderilen", $dusulecek_bakiye, PDO::PARAM_STR);
                        $sorgu->bindValue(":kul_id", $_SESSION["kullanici_id"], PDO::PARAM_INT);
                        $sorgu->bindValue(":eklenme_tarihi", time(), PDO::PARAM_INT);
                        $sorgu->bindValue(":icerik", $mesaj, PDO::PARAM_STR);
                        $sorgu->execute();
                        if ($sorgu->rowCount() > 0) {
                            $son_id = $pdo->lastInsertId();

                            $m_kaydet = $pdo->prepare("INSERT INTO gonderilen_numaralar VALUES(NULL,?,?,?)");
                            $numaralar = "";
                            $ilaves = array_slice($ilaveler, $basla, 5000);
                            foreach ($ilaves as $key) {
                                if (!in_array(tel($key), $kara_numaralar)) {
                                    $m_kaydet->execute(array($_SESSION["kullanici_id"], $son_id, tel($key)));
                                    $numaralar = $numaralar . "," . $key;
                                }
                            }

                            $numaralar = substr($numaralar, 1);
                            // Gönderim Otomatik ise SMS Gönder
                            if ($sms_sekli == 1) {
                                $data = array(
                                    "users" => array(
                                        "username" => "evosms",
                                        "password" => "kt7735"
                                    ),
                                    "DataCoding" => "Default",
                                    "Header" => array(
                                        "Sender" => $baslik->baslik
                                    ),
                                    "Message" => $mesaj,
                                    "Number" => $numaralar,
                                    "Blacklist" => "false"
                                );

                                $data_string = json_encode($data);
                                $header_type = array('Content-Type: application/json');
                                $ch = curl_init();
                                curl_setopt($ch, CURLOPT_URL, "https://api.vuxpanel.com/Json/Submit");
                                curl_setopt($ch, CURLOPT_POST, 1);
                                curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                curl_setopt($ch, CURLOPT_HTTPHEADER, $header_type);
                                curl_setopt($ch, CURLOPT_HEADER, 0);
                                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                                curl_setopt($ch, CURLOPT_TIMEOUT, 120);
                                $result = curl_exec($ch);

                                $obj = json_decode($result);
                                $durum = $obj->Response->Status->Code;

                                if ($durum == 0 || $durum == "0") {
                                    $api_donen_key = $obj->Response->MessageId;

                                    $gg = $pdo->prepare("UPDATE gonderilen_mesajlar SET api_donen_key=:key,durum=1 WHERE id=:id");
                                    $gg->execute(array(":key" => $api_donen_key, ":id" => $son_id));
                                    if ($gg->rowCount() == 0) {
                                        uyari("Olmadı");
                                    }
                                }
                            }
                        }
                        $basla = $basla + 5000;
                    }
                    bilgi("Mesajınız Başarıyla Gönderildi.");
                    $dus = $pdo->prepare("UPDATE kullanicilar SET bakiye = bakiye - :sayi WHERE id=:id");
                    $dus->execute(array(":sayi" => $dusulecek_bakiye, ":id" => $_SESSION["kullanici_id"]));
                } else {
                    // Mesaj gönderim seçeneğini kontrol et. Otomatik ise api ile gönderilsin, manuelse sadece db'ye kayıt yapsın.
                    $sorgu = $pdo->prepare("INSERT INTO gonderilen_mesajlar VALUES(NULL,
                        :kul_id,
                        :baslik,
                        :icerik,
                        :sms_gonderim_sekli,
                        :gonderilen,
                        '0',
                        '0',
                        '0',
                        :eklenme_tarihi,
                        '',
                        '0'
                    )");

                    if ($sms_sekli == 0) { // Manuel Gönder
                        $sorgu->bindValue(":sms_gonderim_sekli", 0, PDO::PARAM_INT);
                    } else if ($sms_sekli == 1) { // Otomatik Gönder
                        $sorgu->bindValue(":sms_gonderim_sekli", 1, PDO::PARAM_INT);
                    }
                    $sorgu->bindValue(":baslik", $baslik->baslik, PDO::PARAM_STR);
                    $sorgu->bindValue(":gonderilen", $dusulecek_bakiye, PDO::PARAM_STR);
                    $sorgu->bindValue(":kul_id", $_SESSION["kullanici_id"], PDO::PARAM_INT);
                    $sorgu->bindValue(":eklenme_tarihi", time(), PDO::PARAM_INT);
                    $sorgu->bindValue(":icerik", $mesaj, PDO::PARAM_STR);
                    $sorgu->execute();
                    if ($sorgu->rowCount() > 0) {
                        bilgi("Mesajınız Başarıyla Gönderildi.");
                        $son_id = $pdo->lastInsertId();
                        // Bakiyeden Düş
                        $dus = $pdo->prepare("UPDATE kullanicilar SET bakiye = bakiye - :sayi WHERE id=:id");
                        $dus->execute(array(":sayi" => $dusulecek_bakiye, ":id" => $_SESSION["kullanici_id"]));

                        $m_kaydet = $pdo->prepare("INSERT INTO gonderilen_numaralar VALUES(NULL,?,?,?)");
                        $numaralar = "";
                        foreach ($ilaveler as $key) {
                            if (!in_array(tel($key), $kara_numaralar)) {
                                $m_kaydet->execute(array($_SESSION["kullanici_id"], $son_id, tel($key)));
                                $numaralar = $numaralar . "," . $key;
                            }
                        }

                        $numaralar = substr($numaralar, 1);
                        // Gönderim Otomatik ise SMS Gönder
                        if ($sms_sekli == 1) {
                            $data = array(
                                "users" => array(
                                    "username" => "evosms",
                                    "password" => "kt7735"
                                ),
                                "DataCoding" => "Default",
                                "Header" => array(
                                    "Sender" => $baslik->baslik
                                ),
                                "Message" => $mesaj,
                                "Number" => $numaralar,
                                "Blacklist" => "false"
                            );

                            $data_string = json_encode($data);
                            $header_type = array('Content-Type: application/json');
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL, "https://api.vuxpanel.com/Json/Submit");
                            curl_setopt($ch, CURLOPT_POST, 1);
                            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                            curl_setopt($ch, CURLOPT_HTTPHEADER, $header_type);
                            curl_setopt($ch, CURLOPT_HEADER, 0);
                            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                            curl_setopt($ch, CURLOPT_TIMEOUT, 120);
                            $result = curl_exec($ch);

                            $obj = json_decode($result);
                            $durum = $obj->Response->Status->Code;

                            if ($durum == 0 || $durum == "0") {
                                $api_donen_key = $obj->Response->MessageId;

                                $gg = $pdo->prepare("UPDATE gonderilen_mesajlar SET api_donen_key=:key,durum=1 WHERE id=:id");
                                $gg->execute(array(":key" => $api_donen_key, ":id" => $son_id));
                                if ($gg->rowCount() == 0) {
                                    uyari("Olmadı");
                                }
                            }
                        }
                    }
                }
            }
            ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="card-heading p-4">
                                <div class="mini-stat-icon float-right">
                                    <i class="mdi mdi-cellphone-sound bg-primary text-white"></i>
                                </div>
                                <div>
                                    <?php
                                    $baki = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
                                    $baki->execute(array(":id" => $_SESSION["kullanici_id"]));
                                    $bakiye = $baki->fetch(PDO::FETCH_OBJ);
                                    ?>
                                    <h5 class="font-16">Mevcut Bakiyeniz</h5>
                                </div>
                                <h3 class="mt-4"><?=$bakiye->bakiye;?></h3>
                                <div class="progress mt-4" style="height: 4px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-6">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-checkbox-marked-circle-outline bg-success text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Gönderilen SMS</h5>
                            </div>
                            <h3 class="mt-4"><?=$dusulecek_bakiye ?? 0;?></h3>
                            <div class="progress mt-4" style="height: 4px;">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="88" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- container-fluid -->
    </div>
</div>

<?php
require_once "footer.php";
?>

<!-- Tabisms Teması için Özel Stil -->
<style>
    .content-page {
        background: transparent;
    }

    .content {
        padding-top: 10px; /* Üstteki boşluğu azalttık */
        position: relative;
        z-index: 5;
    }

    .container-fluid {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    .card {
        background: #2a2a4a;
        border: none;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
        position: relative;
        margin-bottom: 30px;
    }

    .card-body {
        padding: 20px;
    }

    .card-heading {
        position: relative;
        padding: 15px; /* Kart başlığı için padding azaltıldı */
    }

    .mini-stat-icon {
        position: absolute;
        top: 15px;
        right: 15px;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .mini-stat-icon i {
        font-size: 20px;
    }

    .bg-primary {
        background: #ff147f !important;
    }

    .bg-success {
        background: #00ff7f !important;
    }

    .bg-warning {
        background: #ffeb3b !important;
    }

    .text-white {
        color: #fff !important;
    }

    .font-16 {
        font-size: 16px;
        color: #ccc;
    }

    h3 {
        font-size: 32px;
        color: #fff;
        margin: 10px 0; /* Başlık için üst ve alt boşluk azaltıldı */
    }

    .progress {
        height: 4px;
        background: #3a3a5a;
        border-radius: 2px;
        margin-top: 10px; /* İlerleme çubuğu için üst boşluk azaltıldı */
    }

    .progress-bar {
        border-radius: 2px;
    }

    .alert {
        background: #ff147f;
        color: #fff;
        padding: 10px;
        border-radius: 10px;
        text-align: center;
        font-size: 14px;
    }

    /* Responsive Tasarım */
    @media (max-width: 768px) {
        .content {
            padding-top: 5px;
        }

        .card-body {
            padding: 15px;
        }

        .card-heading {
            padding: 10px;
        }

        h3 {
            font-size: 24px;
            margin: 8px 0;
        }

        .font-16 {
            font-size: 14px;
        }

        .mini-stat-icon {
            top: 10px;
            right: 10px;
            width: 35px;
            height: 35px;
        }

        .mini-stat-icon i {
            font-size: 18px;
        }

        .progress {
            margin-top: 8px;
        }

        .alert {
            font-size: 12px;
        }
    }
</style>