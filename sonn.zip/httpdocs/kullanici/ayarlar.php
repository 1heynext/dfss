<?php

require_once "header.php";
require_once "left.php";

?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Ayarlar</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <!-- end page-title -->

            <div class="row">
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <?php
                            if(isset($_GET)) {
                                if(isset($_GET["action"])){
                                    if($_GET["action"]=="k_kaydet") {
                                        $eski_parola = trim($_POST["eski_parola"]);
                                        $yeni_parola = trim($_POST["yeni_parola"]);
                                        $yeni_parola_tekrar = trim($_POST["yeni_parola_tekrar"]);

                                        // Boş alan kontrolü
                                        if($eski_parola == "" || $yeni_parola == "" || $yeni_parola_tekrar == "") {
                                            uyari("Lütfen Boş Alan Bırakmayınız");
                                        } else {
                                            // Eski parolanın doğruluğunu kontrol et
                                            $ss = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
                                            $ss->execute(array(":id" => $_SESSION["kullanici_id"]));
                                            $s = $ss->fetch(PDO::FETCH_OBJ);

                                            if($s->parola_md5 !== md5($eski_parola)) {
                                                uyari("Eski Parola Yanlış");
                                            } else {
                                                // Yeni parola ile yeni parola tekrar eşleşiyor mu?
                                                if($yeni_parola !== $yeni_parola_tekrar) {
                                                    uyari("Yeni Parola ve Yeni Parola Tekrar Eşleşmiyor");
                                                } else {
                                                    // Parolayı güncelle
                                                    $kaydet = $pdo->prepare("UPDATE kullanicilar SET parola=:parola, parola_md5=:parola_md5 WHERE id=:id");
                                                    $kaydet->bindValue(":id", $_SESSION["kullanici_id"], PDO::PARAM_INT);
                                                    $kaydet->bindValue(":parola", $yeni_parola, PDO::PARAM_STR);
                                                    $kaydet->bindValue(":parola_md5", md5($yeni_parola), PDO::PARAM_STR);
                                                    $kaydet->execute();
                                                    if($kaydet->rowCount() > 0) {
                                                        bilgi("Bilgiler Güncellendi.");
                                                    } else {
                                                        uyari("Parola Güncellenirken Bir Hata Oluştu");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            $ss = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
                            $ss->execute(array(":id" => $_SESSION["kullanici_id"]));
                            $s = $ss->fetch(PDO::FETCH_OBJ);
                            ?>
                            <h4 class="mt-0 header-title">Kullanıcı Bilgileri Düzenle</h4>
                            <hr>
                            <form method="post" action="?action=k_kaydet">
                                <div class="form-group">
                                    <label>Eski Parola</label>
                                    <div>
                                        <input type="password" name="eski_parola" id="eski_parola" class="form-control" required placeholder="Eski Parola"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Yeni Parola</label>
                                    <div>
                                        <input type="password" name="yeni_parola" id="yeni_parola" class="form-control" required placeholder="Yeni Parola"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Yeni Parola Tekrar</label>
                                    <div>
                                        <input type="password" name="yeni_parola_tekrar" id="yeni_parola_tekrar" class="form-control" required placeholder="Yeni Parola Tekrar"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">
                                            Kaydet
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <?php
                            $ss = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
                            $ss->execute(array(":id" => $_SESSION["kullanici_id"]));
                            $s = $ss->fetch(PDO::FETCH_OBJ);
                            ?>
                            <h4 class="mt-0 header-title">API BİLGİLERİ</h4>
                            <hr>
                            <div class="form-group">
                                <label>Api Key</label>
                                <div>
                                    <input type="text" name="parola" id="pass2" value="<?=$s->api_key;?>" class="form-control" readonly />
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="alert alert-success mb-0" role="alert">
                                    <h4 class="alert-heading mt-0 font-18">Bilgilendirme!</h4>
                                    <p>* Api Kullanımı İçin Api Key, Kullanıcı Adı ve Sisteme Giriş Parolanızı Kullanmanız Gerekmektedir.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end row -->
        </div>
        <!-- container-fluid -->
    </div>
</div>

<?php
require_once "footer.php";
?>

<!-- Tabisms Teması için Özel Stil -->
<style>
    .content-page {
        background: transparent;
    }

    .content {
        padding-top: 30px;
        position: relative;
        z-index: 5;
    }

    .container-fluid {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    .page-title-box {
        margin-bottom: 30px;
    }

    .page-title {
        font-size: 28px;
        color: #fff;
        text-align: center;
    }

    .card {
        background: #2a2a4a;
        border: none;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
        position: relative;
        margin-bottom: 30px;
    }

    .card-body {
        padding: 30px;
    }

    .card-heading {
        position: relative;
    }

    .header-title {
        font-size: 24px;
        color: #fff;
        margin-bottom: 20px;
    }

    hr {
        border-top: 1px solid #3a3a5a;
    }

    .form-group label {
        color: #ccc;
        font-size: 14px;
    }

    .form-group input {
        background: #3a3a5a;
        border: none;
        border-radius: 10px;
        color: #fff;
        font-size: 14px;
        padding: 12px;
    }

    .form-group input:focus {
        outline: none;
        box-shadow: 0 0 10px rgba(255, 20, 127, 0.3);
    }

    .form-group input[readonly] {
        background: #3a3a5a;
        color: #ccc;
        cursor: not-allowed;
    }

    .btn-primary {
        background: #ff147f;
        border: none;
        border-radius: 30px;
        padding: 10px 20px;
        font-weight: 600;
        font-size: 14px;
        color: #fff;
        transition: all 0.3s;
    }

    .btn-primary:hover {
        background: #ff4081;
        box-shadow: 0 0 15px rgba(255, 20, 127, 0.5);
    }

    .alert {
        background: #00ff7f;
        color: #1a1a2e;
        padding: 10px;
        border-radius: 10px;
        text-align: center;
        font-size: 14px;
    }

    .alert.alert-success {
        background: #00ff7f;
        color: #1a1a2e;
    }

    .alert-heading {
        font-size: 18px;
        color: #1a1a2e;
    }

    .alert p {
        color: #1a1a2e;
    }

    /* Responsive Tasarım */
    @media (max-width: 768px) {
        .page-title {
            font-size: 24px;
        }

        .header-title {
            font-size: 20px;
        }

        .form-group input {
            font-size: 12px;
            padding: 10px;
        }

        .btn-primary {
            font-size: 12px;
            padding: 8px 16px;
        }

        .alert {
            font-size: 12px;
        }

        .alert-heading {
            font-size: 16px;
        }
    }
</style>