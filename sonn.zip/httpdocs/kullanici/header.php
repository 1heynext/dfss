<?php

require_once "../config.php";
require_once "../functions.php";

if (!isset($_SESSION["kullanici_kul_adi"]) || !isset($_SESSION["kullanici_id"]) || $_SESSION["login"] == false) {
    header("Location:login.php");
    exit();
}

if (isset($_GET)) {
    if (isset($_GET["action"])) {
        if ($_GET["action"] == "logout") {
            session_destroy();
            session_unset();
            header("Location:login.php");
            exit();
        }
    }
}

$kk = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
$kk->execute(array(":id" => $_SESSION["kullanici_id"]));
if ($kk->rowCount() > 0) {
    $k = $kk->fetch(PDO::FETCH_OBJ);
    $bas = $pdo->prepare("SELECT * FROM basliklar WHERE id=:id");
    $bas->execute(array(":id" => $k->baslik));
    $baslik = $bas->fetch(PDO::FETCH_OBJ);
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>Tabisms - Yönetim Paneli</title>
    <meta content="Tabisms" name="description" />
    <meta content="Tabisms" name="author" />
    <link rel="shortcut icon" href="../assets/images/favicon.ico">

    <!--Morris Chart CSS -->
    <link rel="stylesheet" href="../../plugins/morris/morris.css">

    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/icons.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/style.css" rel="stylesheet" type="text/css">

    <!-- DataTables -->
    <link href="../../plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="../../plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="../../plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />

    <!-- Tabisms Teması için Özel Stil -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            color: #fff;
            overflow-x: hidden;
            position: relative;
        }

        /* Topbar ve Navbar */
        .topbar {
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            border-bottom: 1px solid #3a3a5a;
            position: relative;
            z-index: 10;
        }

        .topbar-left {
            background: linear-gradient(135deg, #1a1a2e, #16213e);
        }

        .logo-light {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-light img {
            max-width: 200px;
            height: auto;
        }

        .logo-sm {
            display: none;
        }

        .logo-sm img {
            max-width: 60px;
            height: auto;
        }

        /* Menü gizlendiğinde logonun boyutunu ve konumunu sabitleme */
        .logo-light img, .logo-sm img {
            transition: none !important;
        }

        .topbar-left .logo {
            position: relative;
            left: 0 !important;
        }

        .navbar-custom {
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* Yatay Menü Stilleri */
        .navbar-menu {
            display: flex;
            align-items: center;
            gap: 15px; /* Menü elemanları arasında boşluk */
        }

        .navbar-menu li {
            list-style: none;
        }

        .navbar-menu li a {
            color: #ccc !important;
            transition: all 0.3s;
            padding: 10px 15px;
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .navbar-menu li a i {
            color: #ff147f;
            font-size: 16px;
        }

        .navbar-menu li a:hover {
            color: #fff !important;
            background: #3a3a5a;
            border-radius: 5px;
        }

        .navbar-menu li a span {
            font-size: 14px;
        }

        /* Sağ Taraftaki Butonlar */
        .navbar-right {
            display: flex;
            align-items: center;
            gap: 15px; /* Butonlar arasında boşluk */
        }

        .nav-link {
            color: #ccc !important;
            transition: all 0.3s;
        }

        .nav-link:hover {
            color: #fff !important;
        }

        .nav-link i {
            color: #ff147f;
        }

        .dropdown-menu {
            background: #2a2a4a !important; /* Dropdown menü arka planı */
            border: none;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
        }

        .dropdown-menu .dropdown-item {
            color: #ccc !important; /* Metin rengi */
            background: #2a2a4a !important; /* Ayarlar yazısının arka planını temaya uygun hale getir */
            transition: all 0.3s;
        }

        .dropdown-menu .dropdown-item:hover {
            background: #3a3a5a !important; /* Hover durumunda arka plan */
            color: #fff !important;
        }

        .dropdown-menu .dropdown-item i {
            color: #ff147f;
        }

        .dropdown-menu .dropdown-item.text-danger {
            color: #ff6b6b !important;
        }

        .dropdown-menu .dropdown-item.text-danger i {
            color: #ff6b6b;
        }

        .dropdown-menu .dropdown-divider {
            border-top: 1px solid #3a3a5a; /* Divider rengi */
        }

        .nav-pro-img img {
            border: 2px solid #ff147f;
        }

        /* Responsive Tasarım */
        @media (max-width: 768px) {
            .topbar-left {
                text-align: center;
            }

            .logo-light img {
                max-width: 150px;
            }

            .navbar-custom {
                flex-direction: column;
                gap: 10px;
            }

            .navbar-menu {
                flex-direction: column;
                width: 100%;
                gap: 10px;
            }

            .navbar-menu li a {
                padding: 8px 10px;
            }

            .navbar-menu li a i {
                font-size: 14px;
            }

            .navbar-menu li a span {
                font-size: 12px;
            }

            .navbar-right {
                flex-direction: column;
                gap: 10px;
            }
        }

        @media (max-width: 480px) {
            .logo-light img {
                max-width: 120px;
            }
        }
    </style>
</head>

<body>
    <!-- Begin page -->
    <div id="wrapper">
        <!-- Top Bar Start -->
        <div class="topbar">
            <!-- LOGO -->
            <div class="topbar-left">
                <a href="index.php" class="logo">
                    <span class="logo-light">
                        <img src="../images/logo.png" alt="Tabisms Logo">
                    </span>
                    <span class="logo-sm">
                        <img src="../images/logo.png" alt="Tabisms Logo">
                    </span>
                </a>
            </div>

            <nav class="navbar-custom">
                <!-- Yatay Menü -->
                <ul class="navbar-menu">
                    <li>
                        <a href="index.php" class="waves-effect">
                            <i class="icon-accelerator"></i> <span> Anasayfa </span>
                        </a>
                    </li>
                    <li>
                        <a href="mesaj_gonder.php" class="waves-effect">
                            <i class="icon-dialogue-happy"></i> <span> Mesaj Gönder </span>
                        </a>
                    </li>
                    <li>
                        <a href="raporlar.php" class="waves-effect">
                            <i class="icon-graph"></i> <span> Raporlar </span>
                        </a>
                    </li>
                    <li>
                        <a href="faturalandirma.php" class="waves-effect">
                            <i class="icon-graph-rising"></i> <span> Faturalandırma </span>
                        </a>
                    </li>
                    <li>
                        <a href="/destek.php" class="waves-effect">
                            <i class="mdi mdi-face-agent"></i> <span> Destek </span>
                        </a>
                    </li>
                </ul>

                <!-- Sağ Taraftaki Butonlar -->
                <ul class="navbar-right list-inline float-right mb-0">
                    <!-- full screen -->
                    <li class="dropdown notification-list list-inline-item d-none d-md-inline-block">
                        <a class="nav-link waves-effect" href="#" id="btn-fullscreen">
                            <i class="mdi mdi-arrow-expand-all noti-icon"></i>
                        </a>
                    </li>

                    <li class="dropdown notification-list list-inline-item d-none d-md-inline-block">
                        <a class="dropdown-item d-block" href="ayarlar.php"><i class="mdi mdi-settings"></i> Ayarlar</a>
                    </li>

                    <li class="dropdown notification-list list-inline-item">
                        <div class="dropdown notification-list nav-pro-img">
                            <a class="dropdown-toggle nav-link arrow-none nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <img src="../assets/images/users/user.png" alt="user" class="rounded-circle">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right profile-dropdown">
                                <a class="dropdown-item d-block" href="ayarlar.php"><i class="mdi mdi-settings"></i> Ayarlar</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="?action=logout"><i class="mdi mdi-power text-danger"></i> Güvenli Çıkış</a>
                            </div>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>
        <!-- Top Bar End -->

        <!-- Tam Ekran Butonu için JavaScript -->
        <script>
            document.getElementById('btn-fullscreen').addEventListener('click', function() {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen().catch(err => {
                        console.log(`Tam ekran moduna geçiş başarısız: ${err.message}`);
                    });
                } else {
                    document.exitFullscreen().catch(err => {
                        console.log(`Tam ekrandan çıkış başarısız: ${err.message}`);
                    });
                }
            });
        </script>