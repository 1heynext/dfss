<?php
require_once "header.php";
require_once "../functions.php";
?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="card-heading p-4">
                                <div class="mini-stat-icon float-right">
                                    <i class="mdi mdi-cellphone-sound"></i>
                                </div>
                                <div>
                                    <?php
                                    $baki = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
                                    $baki->execute(array(":id"=>$_SESSION["kullanici_id"]));
                                    $bakiye = $baki->fetch(PDO::FETCH_OBJ);
                                    ?>
                                    <h5 class="font-16">Mevcut Bakiyeniz</h5>
                                </div>
                                <h3 class="mt-4"><?=$bakiye->bakiye;?></h3>
                                <div class="progress mt-4" style="height: 4px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card m-b-30">
                        <div class="card-body">
                            <h4 class="mt-0 header-title mb-4">Son 5 Bakiye İşleminiz</h4>
                            <div class="friends-suggestions">
                                <?php
                                $guncel_bakiye = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
                                $guncel_bakiye->execute(array(":id"=>$_SESSION["kullanici_id"]));
                                $gg = $guncel_bakiye->fetch(PDO::FETCH_OBJ);

                                $bakiye = $pdo->prepare("SELECT * FROM kullanici_bakiye_hareketleri WHERE kul_id=:kul_id LIMIT 0,5");
                                $bakiye->execute(array(":kul_id"=>$_SESSION["kullanici_id"]));
                                if($bakiye->rowCount()==0) {
                                    uyari("Herhangi Bir Bakiye İşleminiz Bulunmamaktadır.");
                                } else {
                                    while(false !== $b =$bakiye->fetch(PDO::FETCH_OBJ)) {
                                        ?>
                                        <a href="#" class="friends-suggestions-list">
                                            <div class="border-bottom position-relative">
                                                <div class="float-left mb-0 mr-3">
                                                    <div class="mini-stat-icon float-right">
                                                        <i class="mdi mdi-briefcase-check"></i>
                                                    </div>
                                                </div>
                                                <div class="desc">
                                                    <h5 class="font-14 mb-1 pt-2 text-dark">Bakiye Miktarı: <?=$b->bakiye_miktari;?></h5>
                                                    <p class="text-muted">Tarih/Saat: <?=date("d.m.Y / H:i",$b->eklenme_tarihi);?></p>
                                                </div>
                                            </div>
                                        </a>
                                        <?php
                                    }
                                }
                                $mesajlar = $pdo->prepare("SELECT SUM(iletilen) as iletilen , SUM(hatali) as hatali, SUM(beklemede) as beklemede FROM gonderilen_mesajlar WHERE kul_id=:kul_id");
                                $mesajlar->execute(array(":kul_id"=>$_SESSION["kullanici_id"]));
                                if($mesajlar->rowCount()>0) {
                                    $msj = $mesajlar->fetch(PDO::FETCH_OBJ);
                                    $iletilen = $msj->iletilen;
                                    $hatali = $msj->hatali;
                                    $beklemede = $msj->beklemede;
                                } else {
                                    $iletilen = 0;
                                    $hatali = 0;
                                    $beklemede = 0;
                                }
                                $gonderilen = $pdo->prepare("SELECT SUM(gonderilen_filtresiz) as gonderilen FROM gonderilen_mesajlar WHERE kul_id=:kul_id");
                                $gonderilen->execute(array(":kul_id"=>$_SESSION["kullanici_id"]));
                                $gon = $gonderilen->fetch(PDO::FETCH_OBJ);
                                ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="row">
                        <div class="col-sm-6 col-xl-6">
                            <div class="card">
                                <div class="card-heading p-4">
                                    <div class="mini-stat-icon float-right">
                                        <i class="mdi mdi-cellphone-sound"></i>
                                    </div>
                                    <div>
                                        <h5 class="font-16">Gönderilen</h5>
                                    </div>
                                    <h3 class="mt-4"><?=$gon->gonderilen;?></h3>
                                    <div class="progress mt-4" style="height: 4px;">
                                        <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-6">
                            <div class="card">
                                <div class="card-heading p-4">
                                    <div class="mini-stat-icon float-right">
                                        <i class="mdi mdi-checkbox-marked-circle-outline"></i>
                                    </div>
                                    <div>
                                        <h5 class="font-16">İletilen</h5>
                                    </div>
                                    <h3 class="mt-4"><?=$iletilen;?></h3>
                                    <div class="progress mt-4" style="height: 4px;">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="88" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-6">
                            <div class="card">
                                <div class="card-heading p-4">
                                    <div class="mini-stat-icon float-right">
                                        <i class="mdi mdi-cellphone-off"></i>
                                    </div>
                                    <div>
                                        <h5 class="font-16">Hatalı</h5>
                                    </div>
                                    <h3 class="mt-4"><?=$hatali;?></h3>
                                    <div class="progress mt-4" style="height: 4px;">
                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 100%" aria-valuenow="68" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- container-fluid -->
    </div>
    <!-- content -->
</div>

<!-- Tabisms Teması için Özel Stil -->
<style>
    .content-page {
        background: transparent;
    }

    .content {
        padding-top: 30px;
        position: relative;
        z-index: 5;
    }

    .container-fluid {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    .card {
        background: #2a2a4a;
        border: none;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
        position: relative;
        margin-bottom: 30px;
    }

    .card-body {
        padding: 30px;
    }

    .card-heading {
        position: relative;
    }

    .mini-stat-icon {
        position: absolute;
        top: 20px;
        right: 20px;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: #2a2a4a !important; /* Arka plan kartla aynı renk */
        box-shadow: 0 0 8px rgba(255, 20, 127, 0.3); /* Hafif pembe gölge */
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 8px; /* İkonun çevresinde biraz boşluk */
    }

    .mini-stat-icon i {
        font-size: 20px;
        color: #ff147f; /* İkon rengi temanın birincil rengi (pembe) */
    }

    .bg-primary {
        background: #ff147f !important;
    }

    .bg-success {
        background: #00ff7f !important;
    }

    .bg-warning {
        background: #ffeb3b !important;
    }

    .text-white {
        color: #fff !important;
    }

    .font-16 {
        font-size: 16px;
        color: #ccc;
    }

    h3 {
        font-size: 32px;
        color: #fff;
        margin: 20px 0;
    }

    .progress {
        height: 4px;
        background: #3a3a5a;
        border-radius: 2px;
        margin-top: 20px;
    }

    .progress-bar {
        border-radius: 2px;
    }

    .header-title {
        font-size: 24px;
        color: #fff;
        margin-bottom: 20px;
    }

    .friends-suggestions-list {
        display: flex;
        align-items: center;
        padding: 10px 0;
        border-bottom: 1px solid #3a3a5a;
        text-decoration: none;
        color: #fff;
    }

    .friends-suggestions-list .desc {
        flex: 1;
        text-align: left;
    }

    .friends-suggestions-list h5 {
        font-size: 14px;
        margin-bottom: 5px;
        color: #fff;
    }

    .friends-suggestions-list p {
        font-size: 12px;
        color: #ccc;
        margin: 0;
    }

    .text-muted {
        color: #ccc !important;
    }

    .text-dark {
        color: #fff !important;
    }

    .alert {
        background: #ff147f;
        color: #fff;
        padding: 10px;
        border-radius: 10px;
        text-align: center;
        font-size: 14px;
    }

    /* Responsive Tasarım */
    @media (max-width: 768px) {
        .content {
            padding-top: 20px;
        }

        h3 {
            font-size: 24px;
            margin: 15px 0;
        }

        .font-16 {
            font-size: 14px;
        }

        .card-body {
            padding: 20px;
        }

        .mini-stat-icon {
            top: 15px;
            right: 15px;
            width: 35px;
            height: 35px;
            padding: 6px;
        }

        .mini-stat-icon i {
            font-size: 18px;
        }

        .friends-suggestions-list h5 {
            font-size: 12px;
        }

        .friends-suggestions-list p {
            font-size: 10px;
        }

        .progress {
            margin-top: 15px;
        }

        .alert {
            font-size: 12px;
        }
    }
</style>