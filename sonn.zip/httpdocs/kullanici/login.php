<?php
  session_start();
  require_once "../config.php";
  require_once "../functions.php";
?>

<!DOCTYPE html>
<html lang="tr">
<head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>SMS YÖNETİM PANELİ</title>
        <meta content="PHP SMS" name="description" />
        <meta content="PHP SMS" name="author" />
        <link rel="shortcut icon" href="../assets/images/favicon.ico">

        <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="../assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="../assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="../assets/css/style.css" rel="stylesheet" type="text/css">

    </head>

    <body>

        <!-- Begin page -->
        <div class="accountbg"></div>
        <div class="home-btn d-none d-sm-block">

            </div>
            <div class="wrapper-page">
                <div class="card card-pages shadow-none">

                    <div class="card-body">
                        <div class="text-center m-t-0 m-b-15">
                                <a href="index-2.html" class="logo logo-admin"><img src="../assets/images/logo-dark.png" alt="" height="24"></a>
                        </div>
                        <h5 class="font-18 text-center">Kullanıcı Giriş</h5>
                        <?php
                        // Action=login olayı ...
                          if(isset($_GET)) {
                            if(isset($_GET["action"])) {
                              if($_GET["action"]=="login") {

                                $kul_adi = trim($_POST["kul_adi"]);
                                $parola  = trim($_POST["parola"]);


                                $kul_varmi =  $pdo->prepare("select * from kullanicilar where kul_adi=:kul_adi and parola_md5=:parola");
                                $kul_varmi->bindValue(":kul_adi",$kul_adi,PDO::PARAM_STR);
                                $kul_varmi->bindValue(":parola",md5($parola),PDO::PARAM_STR);
                                $kul_varmi->execute();

                                if($kul_adi=="" || $parola=="") {
                                uyari("Tüm Bilgileri Doldurunuz.");
                                  }elseif($kul_varmi->rowCount()==0) {
                                    uyari("Kullanıcı Adı veya Parola Hatalı");
                                  }else{
                                    session_start();
                                    $veri_al = $kul_varmi->fetch(PDO::FETCH_OBJ);
                                    $_SESSION["kullanici_kul_adi"] = $veri_al->kul_adi;
                                    $_SESSION["kullanici_id"] = $veri_al->id;
                                    $_SESSION["login"] = true;
                                    header("Location:index.php");
                                    exit();
                                   }
                              }
                            }

                          }

                        ?>

                        <form class="form-horizontal m-t-30" method="post" action="?action=login">

                            <div class="form-group">
                                <div class="col-12">
                                        <label>Kullanıcı Adı</label>
                                    <input class="form-control" type="text" name="kul_adi" required="" placeholder="Kullanıcı Adı">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-12">
                                        <label>Parola</label>
                                    <input class="form-control" type="password" name="parola" required="" placeholder="Parola">
                                </div>
                            </div>

                            <div class="form-group text-center m-t-20">
                                <div class="col-12">
                                    <button class="btn btn-primary btn-block btn-lg waves-effect waves-light" type="submit">Giriş Yap</button>
                                </div>
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        <!-- END wrapper -->
        <!-- jQuery  -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/bootstrap.bundle.min.js"></script>
        <script src="../assets/js/metismenu.min.js"></script>
        <script src="../assets/js/jquery.slimscroll.js"></script>
        <script src="../assets/js/waves.min.js"></script>

        <!-- App js -->
        <script src="../assets/js/app.js"></script>

    </body>
</html>
