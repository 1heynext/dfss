<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabisms - Üyelik Sözleşmesi</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;707&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            color: #fff;
            overflow-x: hidden;
            position: relative;
        }

        /* Dekoratif Arka Plan Objeleri */
        .bg-objects {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }

        .planet {
            position: absolute;
            border-radius: 50%;
            box-shadow: 0 0 20px rgba(107, 72, 255, 0.5);
        }

        .planet.purple {
            width: 150px;
            height: 150px;
            top: 10%;
            left: 10%;
            background: linear-gradient(145deg, #6b48ff, #a29bfe);
            animation: float 10s infinite ease-in-out;
        }

        .planet.dog-planet {
            width: 100px;
            height: 100px;
            bottom: 15%;
            right: 10%;
            background: linear-gradient(145deg, #ff6b6b, #ff8e53);
            animation: float 12s infinite ease-in-out;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }

        /* Header */
        .site-header {
            padding: 20px 50px;
            background: transparent;
            position: relative;
            z-index: 10;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .logo {
            display: flex;
            flex-direction: column;
        }

        .logo img {
            max-width: 250px;
            height: auto;
        }

        .nav-buttons {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
            color: #666;
        }

        .btn.green {
            background: #00ff7f;
        }

        .btn.pink {
            background: #ff147f;
        }

        .btn.yellow {
            background: #ffeb3b;
        }

        .header-container .btn:hover {
            opacity: 0.9;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.3);
            color: #fff;
        }

        .btn svg {
            width: 18px;
            height: 18px;
        }

        /* Sözleşme İçerik Alanı */
        .content-section {
            padding: 50px 20px;
            position: relative;
            z-index: 5;
        }

        .content-container {
            max-width: 800px;
            margin: 0 auto;
            background: #2a2a4a;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
        }

        .content-container h2 {
            font-size: 28px;
            margin-bottom: 20px;
            text-align: center;
            color: #fff;
        }

        .content-container h3 {
            font-size: 20px;
            margin: 20px 0 10px;
            color: #00ff7f;
        }

        .content-container p {
            font-size: 14px;
            color: #ccc;
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .content-container ul {
            list-style-type: disc;
            margin-left: 20px;
            margin-bottom: 15px;
        }

        .content-container li {
            font-size: 14px;
            color: #ccc;
            line-height: 1.6;
            margin-bottom: 8px;
        }

        /* Footer Bölümü */
        footer {
            padding: 40px 20px;
            background: transparent;
            text-align: center;
            position: relative;
            z-index: 5;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .footer-logo img {
            max-width: 300px;
            height: auto;
        }

        .footer-copyright {
            font-size: 16px;
            color: #ccc;
        }

        .footer-copyright span {
            font-weight: bold;
            color: #ff147f;
        }

        .social-icons {
            display: flex;
            gap: 20px;
        }

        .social-icons a {
            display: inline-block;
            transition: all 0.3s;
        }

        .social-icons svg {
            width: 30px;
            height: 30px;
            fill: #fff;
        }

        .social-icons a:hover svg.instagram {
            fill: #e1306c;
        }

        .social-icons a:hover svg.telegram {
            fill: #0088cc;
        }

        .social-icons a:hover svg.twitter {
            fill: #1da1f2;
        }

        /* Responsive Tasarım */
        @media (max-width: 768px) {
            .header-container {
                flex-direction: column;
                gap: 20px;
            }

            .nav-buttons {
                flex-direction: column;
                align-items: center;
            }

            .content-container {
                padding: 20px;
            }

            .content-container h2 {
                font-size: 24px;
            }

            .content-container h3 {
                font-size: 18px;
            }

            .footer-logo img {
                max-width: 250px;
            }
        }

        @media (max-width: 480px) {
            .logo img {
                max-width: 180px;
            }

            .content-container h2 {
                font-size: 20px;
            }

            .content-container h3 {
                font-size: 16px;
            }

            .content-container p,
            .content-container li {
                font-size: 12px;
            }

            .footer-logo img {
                max-width: 200px;
            }

            .footer-copyright {
                font-size: 14px;
            }

            .social-icons svg {
                width: 24px;
                height: 24px;
            }
        }
    </style>
</head>
<body>

    <!-- 🌌 Dekoratif Arka Plan Objeleri -->
    <div class="bg-objects">
        <div class="planet purple"></div>
        <div class="planet dog-planet"></div>
    </div>

    <!-- 🧭 HEADER -->
    <header class="site-header">
        <div class="header-container">
            <div class="logo">
                <a href="index.php">
                    <img src="images/logo.png" alt="Tabisms Logo">
                </a>
            </div>
            <nav class="nav-buttons">
                <a href="girisyap.php" class="btn green">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1a1a2e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M16 20h4a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-4"/>
                        <path d="M8 20H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h4"/>
                        <path d="M9 14l3-3-3-3"/>
                        <path d="M15 14l-3-3 3-3"/>
                    </svg>
                    Giriş Yap
                </a>
                <a href="servis.php" class="btn pink">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="3" y1="6" x2="21" y2="6"/>
                        <line x1="3" y1="12" x2="21" y2="12"/>
                        <line x1="3" y1="18" x2="21" y2="18"/>
                    </svg>
                    Servis Listesi
                </a>
                <a href="index.php" class="btn yellow">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1a1a2e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                        <circle cx="9" cy="7" r="4"/>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                    </svg>
                    Kayıt Ol
                </a>
            </nav>
        </div>
    </header>

    <!-- 📜 ÜYELİK SÖZLEŞMESİ -->
    <section class="content-section">
        <div class="content-container">
            <h2>Tabisms Üyelik Sözleşmesi</h2>

            <h3>1. Genel Hükümler</h3>
            <p>Bu üyelik sözleşmesi ("Sözleşme"), Tabisms platformuna ("Platform") kayıt olan kullanıcılar ("Kullanıcı") ile Tabisms arasında akdedilmiştir. Platforma kayıt olarak, bu Sözleşme'nin tüm şartlarını okuduğunuzu, anladığınızı ve kabul ettiğinizi beyan etmiş olursunuz.</p>

            <h3>2. Kullanım Şartları</h3>
            <ul>
                <li>Kullanıcı, Platform'da sunulan hizmetleri yalnızca yasal amaçlarla kullanmayı taahhüt eder.</li>
                <li>Platform'un kötüye kullanımı, sahte hesap oluşturma veya diğer kullanıcıların haklarını ihlal eden davranışlar yasaktır.</li>
                <li>Kullanıcı, hesabının güvenliğinden sorumludur ve hesap bilgilerini üçüncü şahıslarla paylaşmamalıdır.</li>
            </ul>

            <h3>3. Gizlilik Politikası</h3>
            <p>Kullanıcı tarafından sağlanan kişisel bilgiler, Tabisms'in gizlilik politikasına uygun olarak korunacaktır. Bu bilgiler, yalnızca hizmetlerin sağlanması amacıyla kullanılacak ve yasal zorunluluklar dışında üçüncü şahıslarla paylaşılmayacaktır.</p>

            <h3>4. Sorumluluklar</h3>
            <ul>
                <li>Tabisms, Platform'da sunulan hizmetlerin kesintisiz veya hatasız olacağını garanti etmez.</li>
                <li>Kullanıcı, Platform'u kullanımından doğan tüm riskleri kabul eder.</li>
                <li>Tabisms, Kullanıcı'nın Platform'u kullanımından kaynaklanan doğrudan veya dolaylı zararlardan sorumlu tutulamaz.</li>
            </ul>

            <h3>5. Fesih ve Değişiklik</h3>
            <p>Tabisms, bu Sözleşme'yi dilediği zaman değiştirme veya feshetme hakkını saklı tutar. Değişiklikler, Platform'da yayınlandığı tarihte yürürlüğe girer. Kullanıcı, değişiklikleri takip etmekle yükümlüdür.</p>

            <h3>6. İletişim</h3>
            <p>Bu Sözleşme ile ilgili sorularınız için bizimle <a href="mailto:destek@tabisms.com" style="color: #ff147f; text-decoration: none;">destek@tabisms.com</a> adresinden iletişime geçebilirsiniz.</p>
        </div>
    </section>

    <!-- 🖼️ Footer Bölümü -->
    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                <img src="images/logo.png" alt="Tabisms Logo">
            </div>
            <p class="footer-copyright">
                Copyright 2025 <span>Tabisms</span> Tüm Hakları Saklıdır.
            </p>
            <div class="social-icons">
                <a href="https://instagram.com" target="_blank">
                    <svg class="instagram" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M12 2c2.717 0 3.056.01 4.122.06 1.065.05 1.79.218 2.423.465.633.247 1.176.584 1.714 1.122.538.538.875 1.081 1.122 1.714.247.633.415 1.358.465 2.423.05 1.066.06 1.405.06 4.122s-.01 3.056-.06 4.122c-.05 1.065-.218 1.79-.465 2.423-.247.633-.584 1.176-1.122 1.714-.538.538-1.081.875-1.714 1.122-.633.247-1.358.415-2.423.465-1.066.05-1.405.06-4.122.06s-3.056-.01-4.122-.06c-1.065-.05-1.79-.218-2.423-.465-.633-.247-1.176-.584-1.714-1.122-.538-.538-.875-1.081-1.122-1.714-.247-.633-.415-1.358-.465-2.423-.05-1.066-.06-1.405-.06-4.122s.01-3.056.06-4.122c.05-1.065.218-1.79.465-2.423.247-.633.584-1.176 1.122-1.714.538-.538 1.081-.875 1.714-1.122.633-.247 1.358-.415 2.423-.465 1.066-.05 1.405-.06 4.122-.06zm0-2c-2.75 0-3.111.012-4.192.062-1.082.05-1.953.24-2.65.513-.697.273-1.294.644-1.885 1.235-.591.591-.962 1.188-1.235 1.885-.273.697-.463 1.568-.513 2.65-.05 1.081-.062 1.442-.062 4.192s.012 3.111.062 4.192c.05 1.082.24 1.953.513 2.65.273.697.644 1.294 1.235 1.885.591.591 1.188.962 1.885 1.235.697.273 1.568.463 2.65.513 1.081.05 1.442.062 4.192.062s3.111-.012 4.192-.062c1.082-.05 1.953-.24 2.65-.513.697-.273 1.294-.644 1.885-1.235.591-.591.962-1.188 1.235-1.885.273-.697.463-1.568.513-2.65.05-1.081.062-1.442.062-4.192s-.012-3.111-.062-4.192c-.05-1.082-.24-1.953-.513-2.65-.273-.697-.644-1.294-1.235-1.885-.591-.591-1.188-.962-1.885-1.235-.697-.273-1.568-.463-2.65-.513-1.081-.05-1.442-.062-4.192-.062zm0 5.838c-3.405 0-6.162 2.757-6.162 6.162s2.757 6.162 6.162 6.162 6.162-2.757 6.162-6.162-2.757-6.162-6.162-6.162zm0 10.162c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.441s.645 1.441 1.441 1.441 1.441-.645 1.441-1.441-.645-1.441-1.441-1.441z"/>
                    </svg>
                </a>
                <a href="https://telegram.org" target="_blank">
                    <svg class="telegram" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.69.93-1.1.58-.65-.56-1.65-1.75-2.27-2.27-.28-.23-.45-.45-.16-.93l1.13-3.43c.39-1.18.17-1.62-.88-.94L9.5 11.53c-.63.36-1.22.42-1.54.07l-1.63-1.2c-.66-.49-.34-.94.27-1.09 1.94-.49 7.63-2.92 8.54-3.31.43-.18.81.02.9.47z"/>
                    </svg>
                </a>
                <a href="https://twitter.com" target="_blank">
                    <svg class="twitter" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/>
                    </svg>
                </a>
            </div>
        </div>
    </footer>
</body>
</html>