<?php

require_once "header.php";
require_once "left.php";

$id = $_GET["id"];

$kul = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:id");
$kul->execute(array(":id"=>$id));
if($kul->rowCount()==0) {
  header("Location:index.php");
  exit;
} else {
  $k = $kul->fetch(PDO::FETCH_OBJ);
}
?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Kullanıcılar</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <!-- end page-title -->

            <div class="row">
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                          <?php

                            if(isset($_GET)) {
                              if(isset($_GET["action"])){
                                if($_GET["action"]=="k_kaydet") {
                                    $id = $_GET["id"];
                                    $kul_adi = $_POST["kul_adi"];
                                    $parola  = $_POST["parola"];
                                    $bakiye  = $_POST["bakiye"];
                                    $baslik  = $_POST["baslik"];

                                      if($kul_adi=="" || $parola =="" || $bakiye =="" ||  $bakiye ==0) {
                                          uyari("Lütfen Boş Alan Bırakmayınız");
                                        }elseif(!is_numeric($bakiye)) {
                                          uyari("Lütfen Girilen Numarayı Kontrol Ediniz.");
                                        } else {
                                          $kaydet = $pdo->prepare("UPDATE kullanicilar SET kul_adi=:kul_adi,parola=:parola,parola_md5=:parola_md5,bakiye=:bakiye,baslik=:baslik WHERE id=:id");

                                          $kaydet->bindValue(":kul_adi",$kul_adi,PDO::PARAM_STR);
                                          $kaydet->bindValue(":parola",$parola,PDO::PARAM_STR);
                                          $kaydet->bindValue(":parola_md5",md5($parola),PDO::PARAM_STR);
                                          $kaydet->bindValue(":bakiye",$bakiye,PDO::PARAM_INT);
                                          $kaydet->bindValue(":id",$id,PDO::PARAM_INT);
                                          $kaydet->bindValue(":baslik",$baslik,PDO::PARAM_INT);

                                          $kaydet->execute();
                                          if($kaydet->rowCount()>0) {
                                            bilgi("Bilgiler Kaydedildi.");

                                          } else {
                                            uyari("HATA : Bilgiler Kaydedilemedi. Daha Sonra Tekrar Deneyin");
                                          }

                                        }
                                }
                              }

                            }

                          ?>
                            <h4 class="mt-0 header-title">Kullanıcı Düzenle</h4>
                            <hr>
                            <form method="post" action="?action=k_kaydet&id=<?=$id;?>">
                                <div class="form-group">
                                    <label>Kullanıcı Adı</label>
                                    <input type="text" name="kul_adi" class="form-control" value="<?=$k->kul_adi;?>" required placeholder="Kullanıcı Adı"/>
                                </div>
                                <div class="form-group">
                                    <label>Parola</label>
                                    <div>
                                        <input type="password" name="parola" value="<?=$k->parola;?>" id="pass2" class="form-control" required
                                               placeholder="Parola"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>SMS Başlığı</label>
                                    <div>
                                    <select class="form-control" name="baslik" required>
                                        <option value="">Listeden Seçiniz</option>
                                        <?php
                                          $bb = $pdo->query("SELECT * FROM basliklar");
                                          while(false !== $b = $bb->fetch(PDO::FETCH_OBJ)) {
                                            echo "<option value='".$b->id."'";
                                              if($k->baslik == $b->id) echo " selected";
                                            echo ">".$b->baslik."</option>";
                                          }

                                         ?>
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>SMS Bakiyesi</label>
                                    <div>
                                        <input type="number" value="<?=$k->bakiye;?>" name="bakiye" class="form-control" required
                                               parsley-type="email" placeholder="Sayısal Değer Giriniz"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">
                                            Kaydet
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>     <!-- end col -->
                <div class="col-lg-6">
                  <div class="card m-b-30">
                      <div class="card-body">
                        <div class="alert alert-success mb-0" role="alert">
                            <h4 class="alert-heading mt-0 font-18">Bilgilendirme!</h4>
                            <p>Bakiye Tutarında Küsürat Girmek İçin (Virgül) " , " Kullanınız.</p>
                        </div>
                      </div>
                  </div>
                </div><!-- end col -->

            </div> <!-- end row -->
        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
