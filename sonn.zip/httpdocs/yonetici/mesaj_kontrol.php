<?php
require_once "../config.php";


$kontrol = $pdo->prepare("select * from gonderilen_mesajlar where durum=:durum");
$kontrol->bindValue(":durum",0,PDO::PARAM_INT);
$kontrol->execute();
if($kontrol->rowCount()>0) {
  echo "1";
} else {
  echo "0";
}


?>
