<?php
ob_start();
require_once "header.php";
require_once "left.php";

$id = $_GET["id"];
?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Mesaj Durumları</h4>
                      <a href="raporlar.php" class="btn btn-info waves-effect waves-light"> << Geri << </a>
                    </div>
                </div> <!-- end row -->
            </div>
            <!-- end page-title -->

            <div class="row">
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                          <?php

                          if(isset($_GET)) {
                            if(isset($_GET["action"])){
                              if($_GET["action"]=="api") {
                                $id = $_GET["id"];
                                //başlık al
                                $baslik = $pdo->prepare("SELECT * FROM gonderilen_mesajlar WHERE id=:id");
                                $baslik->execute(array(":id"=>$id));
                                $bas = $baslik->fetch(PDO::FETCH_OBJ);


                                $nolar = $pdo->prepare("SELECT * FROM gonderilen_numaralar WHERE mesaj_id=:mesaj_id");
                                $nolar->execute(array(":mesaj_id"=>$id));
                                if($nolar->rowCount()==0) {
                                  uyari("Gönderilecek Numara Bulunamadı");
                                } else {
                                  $numaralar ="";
                                  while(false !== $no = $nolar->fetch(PDO::FETCH_OBJ)) {
                                      $numaralar =$numaralar.",".$no->no;
                                  }

                                  $numaralar = substr($numaralar,1);
                                  $data = array(
                                      "users" =>array(
                                          "username"=>"evosms",
                                          "password"=>"kt7735"
                                      ),
                                      "DataCoding"=>"Default",
                                      "Header"=>array(
                                        "Sender"=>$bas->baslik
                                      ),
                                      "Message" =>$bas->icerik,
                                      "Number" =>$numaralar,
                                      "Blacklist"=>"false"
                                  );

                                  $data_string = json_encode($data);
                                  $header_type =array('Content-Type: application/json');
                                  $ch = curl_init();
                                  curl_setopt($ch, CURLOPT_URL,"https://api.vuxpanel.com/Json/Submit");
                                  curl_setopt($ch, CURLOPT_POST, 1);
                                  curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
                                  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,0);
                                  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
                                  curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
                                  curl_setopt($ch, CURLOPT_HTTPHEADER,$header_type);
                                  curl_setopt($ch, CURLOPT_HEADER, 0);
                                  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                                  curl_setopt($ch, CURLOPT_TIMEOUT, 120);
                                    $result = curl_exec($ch);

                                    $obj = json_decode($result);
                                    $durum = $obj->Response->Status->Code;
                                    if($durum==0 || $durum =="0") {
                                      bilgi("Mesaj API ile Gönderildi");
                                      $gg = $pdo->prepare("UPDATE gonderilen_mesajlar SET durum=1 WHERE id=:id");
                                      $gg->execute(array(":id"=>$id));
                                    } else {
                                      uyari("Mesaj Gönderilemedi");
                                    }


                                }

                              }
                            }
                          }
                            if(isset($_GET)) {
                              if(isset($_GET["action"])){
                                if($_GET["action"]=="k_kaydet") {

                                    $id      = $_GET["id"];
                                    $iletilen  = trim($_POST["iletilen"]);
                                    $beklemede = trim($_POST["beklemede"]);
                                    $hatali  = trim($_POST["hatali"]);

                                      if(isset($_POST["durum"])) {
                                        $durum =1;
                                      } else {
                                        $durum =0;
                                      }

                                      if($iletilen =="" || $beklemede=="" || $hatali=="") {
                                          uyari("Lütfen Boş Alan Bırakmayınız");
                                        } else {
                                          $kaydet = $pdo->prepare("UPDATE gonderilen_mesajlar SET iletilen=:iletilen,hatali=:hatali,beklemede=:beklemede,durum=:durum WHERE id=:id");
                                          $kaydet->execute(array(
                                            ":iletilen"=>$iletilen,
                                            ":hatali"=>$hatali,
                                            ":beklemede"=>$beklemede,
                                            ":durum"=>$durum,
                                            ":id"=>$id

                                          ));

                                          if($kaydet->rowCount()>0) {
                                            bilgi("Bilgiler Kaydedildi.");
                                          }

                                        }
                                }
                              }

                            }

                            if(isset($_GET)) {
                              if(isset($_GET["action"])){
                                if($_GET["action"]=="ret") {
                                  $id = $_GET["id"];
                                  $bakiye = $_GET["bakiye"];
                                  $kul_id = $_GET["kul_id"];

                                  $msj_sil = $pdo->prepare("DELETE FROM gonderilen_mesajlar  WHERE id=:id");
                                  $msj_sil->execute(array(":id"=>$id));

                                  if($msj_sil->rowCount()>0) {
                                    bilgi("Mesaj Gönderimi İptal Edildi");
                                    $no_sil = $pdo->prepare("DELETE FROM gonderilen_numaralar WHERE mesaj_id=:mesaj_id");
                                    $no_sil->execute(array(":mesaj_id"=>$id));

                                    // bakiye iade
                                    $iade = $pdo->prepare("UPDATE kullanicilar SET bakiye = bakiye + :bakiye WHERE id=:kul_id");
                                    $iade->execute(array(":kul_id"=>$kul_id,":bakiye"=>$bakiye));
                                    header("Location:raporlar.php");

                                  }


                                }
                              }
                            }



                            $mesaj = $pdo->prepare("SELECT * FROM gonderilen_mesajlar WHERE id=:id");
                            $mesaj->execute(array(":id"=>$id));
                            $m = $mesaj->fetch(PDO::FETCH_OBJ);


                          ?>
                            <h4 class="mt-0 header-title">Mesaj Durumlarını Belirle</h4>
                            <hr>
                            <form method="post" action="?action=k_kaydet&id=<?=$id;?>">
                                <div class="form-group">
                                    <label>İletilen Mesaj</label>
                                    <input type="number" name="iletilen" class="form-control" value="<?=$m->iletilen;?>" required placeholder="İletilen Mesaj Sayısı"/>
                                </div>
                                <div class="form-group">
                                    <label>Hatalı Mesaj</label>
                                    <input type="number" name="hatali" class="form-control" value="<?=$m->hatali;?>" required placeholder="Hatalı Mesaj Sayısı"/>
                                </div>
                                <div class="form-group">
                                    <label>Beklemede</label>
                                    <input type="number" name="beklemede" class="form-control" value="<?=$m->beklemede;?>" required placeholder="Bekleyen Mesaj Sayısı"/>
                                </div>
                                <div class="form-group">
                                  <label for="">Gönderildi Olarak Belirle</label><br>
                                  <div class="custom-control custom-checkbox">
                                      <input type="checkbox" class="custom-control-input" name="durum" value="1" id="customCheck1" data-parsley-multiple="groups" data-parsley-mincheck="2">
                                      <label class="custom-control-label" for="customCheck1">Gönderildi Olarak İşaretle</label>
                                  </div>
                                </div>
                                <div class="form-group">
                                    <div>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">
                                            Kaydet
                                        </button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>     <!-- end col -->

                <div class="col-lg-6">
                  <div class="card m-b-30">
                      <div class="card-body">
                        <div class="alert alert-success mb-0" role="alert">
                            <h4 class="alert-heading mt-0 font-18">Mesaj Metni!</h4>
                            <p><?=$m->icerik;?></p>
                        </div>
          


                      </div>
                  </div>
                </div><!-- end col -->

            </div> <!-- end row -->
        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
