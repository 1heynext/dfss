<?php

require_once "header.php";
require_once "left.php";

$id = $_GET["id"];
$ba = $pdo->prepare("SELECT * FROM kullanici_bakiye_hareketleri WHERE id=:id");
$ba->execute(array(":id"=>$id));
if($ba->rowCount()==0)
 {
   header("Location:index.php");
   exit;
 } else {
   $b = $ba->fetch(PDO::FETCH_OBJ);
 }

?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Kullanıcı Bakiyeleri</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <!-- end page-title -->

            <div class="row">
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                          <?php

                            if(isset($_GET)) {
                              if(isset($_GET["action"])){
                                if($_GET["action"]=="k_kaydet") {
                                    $id = $_GET["id"];
                                    $bakiye = $_POST["bakiye"];
                                    $tutar  = $_POST["tutar"];

                                    if($tutar=="" || $tutar ==0 || $bakiye =="" ||  $bakiye ==0) {
                                          uyari("Lütfen Boş Alan Bırakmayınız");
                                        }elseif(!is_numeric($bakiye)) {
                                          uyari("Lütfen Girilen Bakiyeyi Kontrol Ediniz.");
                                        } else {
                                          $kaydet = $pdo->prepare("UPDATE kullanici_bakiye_hareketleri SET bakiye_miktari=:miktar,bakiye_tutari=:tutar WHERE id=:id");

                                          $kaydet->bindValue(":id",$id,PDO::PARAM_INT);
                                          $kaydet->bindValue(":miktar",$bakiye,PDO::PARAM_INT);
                                          $kaydet->bindValue(":tutar",$tutar,PDO::PARAM_INT);

                                          $kaydet->execute();
                                          if($kaydet->rowCount()>0) {
                                            bilgi("Bilgiler Güncellendi.");
                                          }
                                        }
                                }
                              }

                            }

                          ?>
                            <h4 class="mt-0 header-title">Bakiye Düzenle</h4><hr>
                            <form method="post" action="?action=k_kaydet&id=<?=$id;?>">
                                <div class="form-group">
                                    <label>Bakiye Miktarı</label>
                                    <input type="number" name="bakiye" value="<?=$b->bakiye_miktari;?>" class="form-control" required placeholder="Bakiye Miktarı"/>
                                </div>
                                <div class="form-group">
                                    <label>Bakiye Tutarı (TL)</label>
                                    <input type="number" name="tutar" value="<?=$b->bakiye_tutari;?>" class="form-control" min="0.01" step="0.01" required placeholder="Bakiye Tutarı"/>
                                </div>
                                <div class="form-group">
                                    <div>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">
                                            Kaydet
                                        </button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                  <div class="card m-b-30">
                      <div class="card-body">
                        <div class="alert alert-success mb-0" role="alert">
                            <h4 class="alert-heading mt-0 font-18">Bilgilendirme!</h4>
                            <p>Kayıt Tarihi ve Saati Sistem Tarafından Otomatik Olarak Eklenmektedir.</p>
                        </div>
                      </div>
                  </div>
                </div><!-- end col -->
            </div> <!-- end row -->
        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
