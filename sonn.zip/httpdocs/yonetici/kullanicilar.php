<?php

require_once "header.php";
require_once "left.php";

if(isset($_GET)) {
  if(isset($_GET["action"])){
    if($_GET["action"]=="sil") {
      $id = $_GET["id"];
      $sil = $pdo->prepare("DELETE FROM kullanicilar WHERE id=:id");
      $sil->execute(array(":id"=>$id));
      if($sil->rowCount()>0) {
        bilgi("Kullanıcı Silindi");
        $msj = $pdo->prepare("DELETE FROM gonderilen_mesajlar WHERE kul_id=:id");
        $msj->execute(array(":id"=>$id));

        $msj2 = $pdo->prepare("DELETE FROM gonderilen_numaralar WHERE kul_id=:id");
        $msj2->execute(array(":id"=>$id));
      } else {
        uyari("Kayıt Sİlinemedi");
      }

    }
  }
}
?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Kullanıcılar</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Kayıtlı Kullanıcılar</h4>
                            <hr>

                            <?php
                            $kull = $pdo->query("SELECT * FROM kullanicilar ORDER BY id DESC");
                            if($kull->rowCount() ==0 ) {
                              uyari("Kayıtlı Kullanıcı Bulunamadı");
                            } else {
                              ?>
                              <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                  <thead>
                                  <tr>
                                      <th>Kullanıcı Adı</th>
                                      <th>Mevcut Bakiye</th>
                                      <th>Toplam Alınan Bakiye</th>
                                      <th>Toplam Fatura Miktarı</th>
                                      <th>Toplam Gön. SMS</th>
                                      <th>Bakiye Ekleme</th>
                                      <th>Bakiye Detayları</th>
                                      <th>İşlemler</th>
                                  </tr>
                                  </thead>

                                  <tbody>
                                    <?php
                                      while(false !== $k = $kull->fetch(PDO::FETCH_OBJ)) {
                                        $vt = $pdo->prepare("select sum(bakiye_miktari) as miktar,sum(bakiye_tutari) as tutar from kullanici_bakiye_hareketleri where kul_id=:kul_id");
                                        $vt->execute(array(":kul_id"=>$k->id));
                                        $vv = $vt->fetch(PDO::FETCH_OBJ);

                                        $gt = $pdo->prepare("SELECT SUM(gonderilen) as toplam FROM gonderilen_mesajlar WHERE kul_id=:kul_id");
                                        $gt->execute(array(":kul_id"=>$k->id));
                                        $gtg = $gt->fetch(PDO::FETCH_OBJ);
                                        ?>
                                        <tr>
                                            <td><?=$k->kul_adi;?></td>
                                            <td><?=$k->bakiye;?></td>
                                            <td><?=$vv->miktar;?></td>
                                            <td><?=$vv->tutar;?> TL</td>
                                            <td><?=$gtg->toplam;?></td>
                                            <td><a href="bakiye_ekle.php?id=<?=$k->id;?>" class="btn btn-primary btn-sm">İşlem Yap</a></td>
                                            <td><a href="bakiye_detaylari.php?id=<?=$k->id;?>" class="btn btn-success   btn-sm">Görüntüle</a></td>
                                            <td> <a href="kullanici_duzenle.php?id=<?=$k->id;?>" alt="Düzenle"><img src="../assets/images/duzenle.png"></a> </i>
                                              <a href="?action=sil&id=<?=$k->id;?>" onclick="return confirm('Kullanıcıyı Silmek İstediğinden Eminmisin? Silerseniz Kullanıcıya Ait Herşey Silinecektir.')"><img src="../assets/images/sil.png" alt="Sil"></a> </i>
                                             </td>
                                        </tr>
                                        <?php
                                      }
                                    ?>
                                  </tbody>
                              </table>
                              <?php

                            }

                             ?>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->




        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
