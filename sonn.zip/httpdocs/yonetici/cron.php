<?php
require_once "../config.php";


$mesajlar = $pdo->query("SELECT * FROM gonderilen_mesajlar WHERE durum=0 ORDER BY id LIMIT 0,1");
if($mesajlar->rowCount()>0) {
  $mesaj = $mesajlar->fetch(PDO::FETCH_OBJ);
  $kul = $pdo->prepare("SELECT * FROM kullanicilar WHERE id=:kul_id");
  $kul->execute(array(":kul_id"=>$mesaj->kul_id));
  $k = $kul->fetch(PDO::FETCH_OBJ);

  $baslik = $pdo->prepare("SELECT * FROM basliklar WHERE id=:id");
  $baslik->execute(array(":id"=>$k->baslik));
  $b = $baslik->fetch(PDO::FETCH_OBJ);

  $nolar = $pdo->prepare("SELECT * FROM gonderilen_numaralar WHERE mesaj_id=:mesaj_id");
  $nolar->execute(array(":mesaj_id"=>$mesaj->id));
  if($nolar->rowCount()>0) {

    $numaralar ="";
    while(false !== $no = $nolar->fetch(PDO::FETCH_OBJ)){
      $numaralar = $numaralar.",".$no->no;

    }
      $numaralar = substr($numaralar,1);
  }

//echo "[".$numaralar."]";
  $data = array(

                "Credential"=>array(
                        "Username"=>"ydhesap89",
                        "Password"=>"bcZTF8XW"

                ),
                    "Header"=>array(
                        "From" =>$b->baslik,
                        "ValidityPeriod"=> 0,
                        "Route"=> 0

                      ),
                    "Message" =>$mesaj->icerik,
                    "To"=>"[".$numaralar."]",
                     "DataCoding"=>"Default"

              );


          $data_string = json_encode($data);
          $header_type =array('Content-Type: application/json');
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL,"http://172.86.75.78/api/json/reply/Submit");
          curl_setopt($ch, CURLOPT_POST, 1);
          curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,0);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
          curl_setopt($ch, CURLOPT_HTTPHEADER,$header_type);
          curl_setopt($ch, CURLOPT_HEADER, 0);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
          curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            $result = curl_exec($ch);

            $obj = json_decode($result);
            $durum_kodu =$obj->Response->Status->Code;
            $mesajId = $obj->Response->MessageId;

          if($durum_kodu ==200 || $durum_kodu =="200") {
            $iletildi = $pdo->prepare("UPDATE gonderilen_mesajlar SET durum =1,api_donen_key=:key,status_code=:status WHERE id=:id");
            $iletildi->execute(array(":id"=>$mesaj->id,":key"=>$mesajId,":status"=>$durum_kodu));
          } else {
            $iletildi = $pdo->prepare("UPDATE gonderilen_mesajlar SET status_code=:status WHERE id=:id");
            $iletildi->execute(array(":status"=>$durum_kodu,":id"=>$mesaj->id));
          }

            //{"Response":{"MessageId":1156884168,"Status":{"Code":200,"Description":"OK"}}}

}
