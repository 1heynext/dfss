<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
              <?php
                  if(isset($_GET["action"]) && $_GET["action"]=="listele") {
                      $b1  = trim($_POST["b1"]);
                      $b2  = trim($_POST["b2"]);
                      if($b1 =="" || $b2=="") {
                        uyari("Tarihleri Boş Bırakmayınız");
                      } else {
                        $f1 = explode("-",$b1);
                        $b1 = mktime(0,0,0,$f1[1],$f1[2],$f1[0]);

                        $f2 = explode("-",$b2);
                        $b2 = mktime(23,59,0,$f2[1],$f2[2],$f2[0]);

                      }
                  } else {
                    $b1 = mktime(0,0,0,date("m"),1,date("Y"));
                    $b2 = mktime(23,59,0,date("m"),date("t"),date("Y"));
                  }


                    // $asas = $pdo->query("SELECT * FROM kullanici_bakiye_hareketleri ORDER BY eklenme_tarihi DESC");
                    // while(false !== $as = $asas->fetch(PDO::FETCH_OBJ)) {
                    //
                    //   echo date("d.m.Y H:i",$as->eklenme_tarihi)." Tutar :".$as->bakiye_tutari." Bakiye Miktarı : ".$as->bakiye_miktari."<br>";
                    // }
                    //
                    // echo "<br><br>Seçilen Tarih Aralığı<br>".date("d.m.Y H:i",$b1)."<br>".date("d.m.Y H:i",$b2);

                $ay_kullanici = $pdo->prepare("SELECT * FROM kullanicilar WHERE eklenme_tarihi >=:b1 and eklenme_tarihi <= :b2");
                $ay_kullanici->execute(array(":b1"=>$b1,":b2"=>$b2));

                $a_toplam_kredi = $pdo->prepare("SELECT SUM(bakiye_miktari) as toplam FROM kullanici_bakiye_hareketleri WHERE eklenme_tarihi >=:b1 and eklenme_tarihi <=:b2");
                $a_toplam_kredi->execute(array(":b1"=>$b1,":b2"=>$b2));
                if($a_toplam_kredi->rowCount()>0) {
                    $a_toplam = $a_toplam_kredi->fetch(PDO::FETCH_OBJ);
                    $toplam_kredi = $a_toplam->toplam;
                } else {
                  $toplam_kredi="0";
                }


                $a_toplam_ucret = $pdo->prepare("SELECT SUM(bakiye_tutari) as tutar FROM kullanici_bakiye_hareketleri WHERE eklenme_tarihi >=:b1 and eklenme_tarihi <=:b2");
                $a_toplam_ucret->execute(array(":b1"=>$b1,":b2"=>$b2));
                if($a_toplam_ucret->rowCount()>0) {
                  $a_toplam_u = $a_toplam_ucret->fetch(PDO::FETCH_OBJ);
                  $toplam_ucret = $a_toplam_u->tutar;
                } else {
                  $toplam_ucret="0";
                }

                // gönderilen mesajlar
                $gonderilen_mesaj=0;
                $msjlar = $pdo->prepare("SELECT * FROM gonderilen_mesajlar WHERE eklenme_tarihi >=:b1 and eklenme_tarihi <= :b2");
                $msjlar->execute(array(":b1"=>$b1,":b2"=>$b2));
                if($msjlar->rowCount()>0) {
                    while(false !== $msj = $msjlar->fetch(PDO::FETCH_OBJ)) {
                        $gonderilen_mesaj = $gonderilen_mesaj + $msj->gonderilen;
                    }
                }

                $filtreli_sms_sayisi = 0;
                $filtre = $pdo->prepare("SELECT SUM(gonderilen) as gonderilen,SUM(gonderilen_filtresiz) as filtresiz FROM gonderilen_mesajlar WHERE eklenme_tarihi >=:b1 and eklenme_tarihi <= :b2");
                $filtre->execute(array(":b1"=>$b1,":b2"=>$b2));
                if($filtre->rowCount()>0) {
                    $ff = $filtre->fetch(PDO::FETCH_OBJ);
                  $filtreli_sms_sayisi = $ff->filtresiz - $ff->gonderilen;
                } else {
                  $filtreli_sms_sayisi =0;
                }



               ?>
                <!-- <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">PHP SMS Yönetim Paneli</h4>
                    </div>
                    <div class="col-sm-2">
                      <form class="form" action="?action=listele" method="post">
                        <label for="">Başlangıç Tarihi</label>
                          <input type="date" name="b1" class="form-control" value="" required>
                    </div>
                    <div class="col-sm-2">
                          <label for="">Bitiş Tarihi</label>
                          <input type="date" name="b2" class="form-control" value="" required>
                    </div>
                    <div class="col-sm-2">
                        <br>
                        <button type="submit" class="btn btn-success" name="button">Filtrele</button>
                      </form>
                    </div>
                </div> -->
                <!-- end row -->
            </div>
            <!-- end page-title -->

            <div class="row">
                <div class="col-sm-6 col-xl-3">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-account-multiple-outline bg-primary  text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Toplam Kullanıcı Sayısı</h5>
                            </div>
                            <h3 class="mt-4"><?=$ay_kullanici->rowCount();?></h3>
                            <div class="progress mt-4" style="height: 4px;">
                                <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                      </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-briefcase-check bg-success text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Toplam Verilen Kredi</h5>
                            </div>
                            <h3 class="mt-4"><?php if($toplam_kredi ==0) { echo "0";} else { echo $toplam_kredi;}?></h3>
                            <div class="progress mt-4" style="height: 4px;">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="88" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-cash-usd bg-warning text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Toplam Alınan Ücret</h5>
                            </div>
                            <h3 class="mt-4"><?php if($toplam_ucret ==0)  { echo "0";} else { echo $toplam_ucret;} ?> TL</h3>
                            <div class="progress mt-4" style="height: 4px;">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 100%" aria-valuenow="68" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-cellphone-message bg-danger text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Toplam Gönd. SMS</h5>
                            </div>
                            <h3 class="mt-4"><?=$gonderilen_mesaj;?></h3>
                            <div class="progress mt-4" style="height: 4px;">
                                <div class="progress-bar bg-danger" role="progressbar" style="width: 100%" aria-valuenow="82" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-cellphone-message bg-danger text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Filtrelenen SMS Sayısı</h5>
                            </div>
                            <h3 class="mt-4"><?php if($filtreli_sms_sayisi ==0)  { echo "0";} else { echo $filtreli_sms_sayisi;} ?></h3>
                            <div class="progress mt-4" style="height: 4px;">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 100%" aria-valuenow="68" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- container-fluid -->
    </div>
    <!-- content -->
    <footer class="footer">
        ©  2020 PHP SMS
    </footer>

</div>
<!-- ============================================================== -->
