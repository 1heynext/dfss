<?php

require_once "header.php";
require_once "left.php";

$id = $_GET["id"];
?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Kullanıcı Bakiye Detayları</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Kayıtlı Raporlar</h4>
                            <hr>

                            <?php
                            $kull = $pdo->prepare("SELECT * FROM kullanici_bakiye_hareketleri WHERE kul_id=:kul_id ORDER BY id DESC");
                            $kull->execute(array(":kul_id"=>$id));
                            if($kull->rowCount() ==0 ) {
                              uyari("Kayıtlı Bakiye Hareketi Bulunamadı");
                            } else {
                              ?>
                              <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                  <thead>
                                  <tr>
                                      <th>ID</th>
                                      <th>Eklenen Bakiye Miktarı</th>
                                      <th>Bakiye Tutarı</th>
                                      <th>Tarih</th>
                                      <th>İşlemler</th>
                                  </tr>
                                  </thead>

                                  <tbody>
                                    <?php
                                      while(false !== $k = $kull->fetch(PDO::FETCH_OBJ)) {
                                        ?>
                                        <tr>
                                            <td><?=$k->id;?></td>
                                            <td><?=$k->bakiye_miktari;?></td>
                                            <td><?=$k->bakiye_tutari;?> TL</td>
                                            <td><?=date("d.m.Y / H:i",$k->eklenme_tarihi);?></td>
                                            <td> <a href="bakiye_duzenle.php?id=<?=$k->id;?>" alt="Düzenle"><img src="../assets/images/duzenle.png"></a> </i>
                                              <a href=""><img src="../assets/images/sil.png" alt="Sil"></a> </i>
                                             </td>
                                        </tr>
                                        <?php
                                      }
                                    ?>
                                  </tbody>
                              </table>
                              <?php

                            }

                             ?>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->




        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
