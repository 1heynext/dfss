<?php

require_once "header.php";
require_once "left.php";


?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Ayarlar</h4>
                        <!-- <a href="?action=nolari_sil" class="btn btn-success waves-effect waves-light">
                          Gönderilen Numaraları Sil
                        </a> -->
                    </div>
                </div>
            </div>
            <!-- end page-title -->

            <div class="row">
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                          <?php
                          if(isset($_GET)) {
                            if(isset($_GET["action"])){
                              if($_GET["action"]=="nolari_sil") {
                                  $sil = $pdo->query("TRUNCATE TABLE gonderilen_numaralar");
                                  if($sil) {
                                    bilgi("Tüm Numaralar Silindi");
                                  }
                              }
                            }
                          }
                            if(isset($_GET)) {
                              if(isset($_GET["action"])){
                                if($_GET["action"]=="k_kaydet") {

                                    $kul_adi = $_POST["kul_adi"];
                                    $parola  = $_POST["parola"];
                                    // $sms  = $_POST["sms"];

                                    if($kul_adi=="" || $parola =="" ) {
                                        uyari("Lütfen Boş Alan Bırakmayınız");
                                      } else {
                                        $kaydet = $pdo->prepare("UPDATE yonetici SET kul_adi=:kul_adi,parola=:parola,parola_md5=:parola_md5,sms_gonderim_sekli=:sms WHERE id=1");

                                        $kaydet->bindValue(":kul_adi",$kul_adi,PDO::PARAM_STR);
                                        $kaydet->bindValue(":parola",$parola,PDO::PARAM_STR);
                                        $kaydet->bindValue(":parola_md5",md5($parola),PDO::PARAM_STR);
                                        $kaydet->bindValue(":sms",$sms,PDO::PARAM_INT);
                                        $kaydet->execute();
                                        if($kaydet->rowCount()>0) {
                                          bilgi("Bilgiler Güncellendi.");
                                        }

                                      }
                                }
                              }

                            }




                            $ss = $pdo->query("SELECT * FROM yonetici WHERE id=1");
                            $s = $ss->fetch(PDO::FETCH_OBJ);


                          ?>
                            <h4 class="mt-0 header-title">Yönetici Bilgileri Düzenle</h4>

                            <hr>
                            <form method="post" action="?action=k_kaydet">
                                <div class="form-group">
                                    <label>Kullanıcı Adı</label>
                                    <input type="text" name="kul_adi" value="<?=$s->kul_adi;?>" class="form-control" required placeholder="Kullanıcı Adı"/>
                                </div>

                                <div class="form-group">
                                    <label>Parola</label>
                                    <div>
                                        <input type="password" name="parola" value="<?=$s->parola;?>" id="pass2" class="form-control" required
                                               placeholder="Parola"/>
                                    </div>
                                </div>
                                <!-- <div class="form-group">
                                  <label for="">SMS Gönderim Şekli</label><br>
                                  <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                      <label class="btn btn-light">
                                          <input type="radio" name="sms" id="option1" value="1"> Otomatik
                                      </label>
                                      <label class="btn btn-light active">
                                          <input type="radio" name="sms" id="option2" value="0"> Manuel
                                      </label>

                                  </div>
                                </div> -->

                                <div class="form-group">
                                    <div>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">
                                            Kaydet
                                        </button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>     <!-- end col -->
            </div> <!-- end row -->
        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
