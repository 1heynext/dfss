<?php

require_once "../config.php";
require_once "../functions.php";

if(!isset($_SESSION["yonetici_kul_adi"]) || $_SESSION["login"]==false) {

header("Location:login.php");
exit();
}

if(isset($_GET))  {
	if(isset($_GET["action"])) {
		if($_GET["action"]=="logout") {
			session_destroy();
	session_unset();
	header("Location:login.php");
	exit();
		}
	}
}


 ?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>SMS Yönetim Paneli</title>
		<meta content="PHP SMS" name="description" />
		<meta content="PHP SMS" name="author" />
    <link rel="shortcut icon" href="../assets/images/favicon.ico">

    <!--Morris Chart CSS -->
    <link rel="stylesheet" href="../../plugins/morris/morris.css">

    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/icons.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/style.css" rel="stylesheet" type="text/css">

    <!-- DataTables -->
    <link href="../../plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="../../plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="../../plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />


</head>

<body>
    <!-- Begin page -->
    <div id="wrapper">

        <!-- Top Bar Start -->
        <div class="topbar">

            <!-- LOGO -->
            <div class="topbar-left">
                <a href="index.php" class="logo">

                    <span class="logo-light">
                          <i class="mdi mdi-camera-control"></i>  PHP SMS
                        </span>
                    <span class="logo-sm">
                            <i class="mdi mdi-camera-control"></i>
                        </span>
                </a>
            </div>

            <nav class="navbar-custom">
                <ul class="navbar-right list-inline float-right mb-0">


                    <!-- full screen -->
                    <li class="dropdown notification-list list-inline-item d-none d-md-inline-block">
                        <a class="nav-link waves-effect" href="#" id="btn-fullscreen">
                            <i class="mdi mdi-arrow-expand-all noti-icon"></i>
                        </a>
                    </li>
										<?php
										$kullanicilar = $pdo->query("SELECT * FROM kullanicilar");

										$msjlar =  $pdo->query("SELECT * FROM gonderilen_mesajlar WHERE durum=0");


										 ?>
                    <!-- notification -->
                    <li class="dropdown notification-list list-inline-item">
                        <a class="nav-link dropdown-toggle arrow-none waves-effect" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                            <i class="mdi mdi-bell-outline noti-icon"></i>
                            <span class="badge badge-pill badge-danger noti-icon-badge"><?=$msjlar->rowCount();?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated dropdown-menu-lg px-1">
                            <!-- item-->
                            <h6 class="dropdown-item-text">
                                    Bildirimler
                                </h6>
                            <div class="slimscroll notification-item-list">
                                <!-- item-->
																<?php
																	if($kullanicilar->rowCount()>0) {
																		while(false !== $kul= $kullanicilar->fetch(PDO::FETCH_OBJ)) {
																				 $msj =  $pdo->prepare("SELECT * FROM gonderilen_mesajlar WHERE durum=0 and kul_id=:kul_id");
																				 $msj->execute(array(":kul_id"=>$kul->id));
																				 if($msj->rowCount()>0) {
																					 ?>
																					 <a href="raporlar.php" class="dropdown-item notify-item active">
																							 <div class="notify-icon bg-success"><i class="mdi mdi-cart-outline"></i></div>
																							 <p class="notify-details"><b><?=$kul->kul_adi." ( ".$msj->rowCount()." )"?></b></p>
																					 </a>
																					 <?php
																				 }
																		}
																	}

																 ?>

                            </div>

                        </div>
                    </li>

                    <li class="dropdown notification-list list-inline-item">
                        <div class="dropdown notification-list nav-pro-img">
                            <a class="dropdown-toggle nav-link arrow-none nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <img src="../assets/images/users/user.png" alt="user" class="rounded-circle">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                <a class="dropdown-item d-block" href="ayarlar.php"><i class="mdi mdi-settings"></i> Ayarlar</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="?action=logout"><i class="mdi mdi-power text-danger"></i> Güvenli Çıkış</a>
                            </div>
                        </div>
                    </li>
                </ul>

                <ul class="list-inline menu-left mb-0">
                    <li class="float-left">
                        <button class="button-menu-mobile open-left waves-effect">
                            <i class="mdi mdi-menu"></i>
                        </button>
                    </li>

                </ul>

            </nav>

        </div>
        <!-- Top Bar End -->
