<?php

require_once "header.php";
require_once "left.php";


?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Raporlar</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Kayıtlı Mesajlar</h4>
                            <hr>

                            <?php


                            $kull = $pdo->query("SELECT * FROM gonderilen_mesajlar ORDER BY id DESC");
                            if($kull->rowCount() ==0 ) {
                              uyari("Kayıtlı Mesaj Bulunamadı");
                            } else {
                              ?>
                              <div class="table-responsive">
                              <table id="raporlar_table" class="table table-bordered" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                  <thead>
                                  <tr>
                                      <th>ID</th>
                                      <th> Kul.Adı</th>
                                      <th> Başlık</th>
                                      <th> İçerik</th>
                                      <th> İşlem Zamanı</th>
                                      <th> Durum</th>
                                      <th> Status<br>Code</th>
                                      <th> Filtresiz Gönderim Sayısı</th>
                                      <th> Gön<br>derilen</th>
                                      <th> İle<br>tilen</th>
                                      <th> İle<br>tilmeyen </th>
                                      <th>İşlemler</th>
                                  </tr>
                                  </thead>

                                  <tbody>

                                    <?php
  /*
                                      while(false !== $k = $kull->fetch(PDO::FETCH_OBJ)) {
                                        $kas = $pdo->prepare("SELECT * FROM gonderilen_numaralar WHERE mesaj_id=:mesaj_id");
                                        $kas->execute(array(":mesaj_id"=>$k->id));

                                        ?>
                                        <tr>
                                            <td><?=$k->id;?></td>
                                            <td><?=$k->baslik;?></td>
                                            <td><?=$k->icerik;?></td>
                                            <td><?=date("d.m.Y / H:i",$k->eklenme_tarihi);?></td>
                                            <td><?php if($k->durum ==0) { echo "Beklemede";} else { echo "Gönderildi";} ?></td>
                                            <td><?=$k->status_code;?></td>
                                            <td><?=$k->gonderilen;?></td>
                                            <td><?=$kas->rowCount();?></td>
                                            <td><?=$k->iletilen;?></td>
                                            <td><?=$k->hatali;?></td>
                                            <td><?=$k->beklemede;?></td>

                                          <td><a href="rapor_detay.php?id=<?=$k->id;?>" class="btn btn-success   btn-sm">Detaylar</a>
                                          <a href="excele_aktar.php?id=<?=$k->id;?>" class="btn btn-info   btn-sm">Excele Aktar</a>
                                          <a href="mesaj_durumlari.php?id=<?=$k->id;?>" class="btn btn-warning   btn-sm">Mesaj Durumları</a>

                                        </td>
                                        </tr>
                                        <?php
                                      }
                                      */
                                    ?>
                                  </tbody>
                              </table>
                            </div>
                              <?php

                            }

                             ?>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->




        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
