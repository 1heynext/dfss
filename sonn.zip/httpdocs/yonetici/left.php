

        <!-- ========== Left Sidebar Start ========== -->
        <div class="left side-menu">
            <div class="slimscroll-menu" id="remove-scroll">

                <!--- Sidemenu -->
                <div id="sidebar-menu">
                    <!-- Left Menu Start -->
                    <ul class="metismenu" id="side-menu">
                        <li class="menu-title">Menu</li>
                        <li>
                            <a href="index.php" class="waves-effect">
                                <i class="icon-accelerator"></i> <span> Anasayfa </span>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="waves-effect"><i class="icon-profile"></i><span> Kullanıcılar <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                            <ul class="submenu">
                                <li><a href="kullanicilar.php">Tüm Kullanıcılar</a></li>
                                <li><a href="kullanici_ekle.php">Kullanıcı Ekle</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="kara_liste.php" class="waves-effect"><i class="icon-calendar"></i><span> Kara Liste </span></a>
                        </li>
                        <li>
                            <a href="basliklar.php" class="waves-effect"><i class="icon-calendar"></i><span> SMS Başlıkları </span></a>
                        </li>
                      
                        <li>
                            <a href="javascript:void(0);" class="waves-effect"><i class="icon-paper-sheet"></i><span> Raporlar <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                            <ul class="submenu">
                                <li><a href="raporlar.php">SMS Raporları</a></li>
                            </ul>
                        </li>
                      </ul>

                </div>
                <!-- Sidebar -->
                <div class="clearfix"></div>

            </div>
            <!-- Sidebar -left -->

        </div>
        <!-- Left Sidebar End -->
