<?php

require_once "header.php";
require_once "left.php";

?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">SMS Başlıkları</h4>
                    </div>
                </div> <!-- end row -->
            </div>
            <!-- end page-title -->
            <?php
            if(isset($_GET)) {
              if(isset($_GET["action"])){
                if($_GET["action"]=="sil") {
                  $id = $_GET["id"];
                  $sil = $pdo->prepare("DELETE FROM basliklar WHERE id=:id");
                  $sil->execute(array(":id"=>$id));
                  if($sil->rowCount()>0) {
                    bilgi("Kayıt Silindi");
                  } else {
                    uyari("Kayıt Sİlinemedi");
                  }

                }
              }
            }
             ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                          <?php

                            if(isset($_GET)) {
                              if(isset($_GET["action"])){
                                if($_GET["action"]=="kaydet") {
                                  $baslik = trim($_POST["baslik"]);

                                  if($baslik =="") {
                                    uyari("Başlık Alanını Boş Bırakmayınız");
                                  }  else {
                                      $ka = $pdo->prepare("INSERT INTO basliklar VALUES(NULL,:baslik)");
                                      $ka->execute(array(":baslik"=>$baslik));
                                      if($ka->rowCount()==0) {
                                        uyari("Kayıt Başarısız");
                                      } else {
                                        bilgi("Başlık Kaydedildi.");
                                      }
                                  }

                                }
                              }

                            }

                          ?>
                            <h4 class="mt-0 header-title">Başlık  Ekle</h4><hr>
                            <form method="post" action="?action=kaydet">
                                <div class="form-group">
                                    <label>SMS Başlığınız</label>
                                  <input type="text" name="baslik" required class="form-control" value="">
                                </div>
                                <div class="form-group">
                                    <div>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">
                                            Kaydet
                                        </button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                          <div class="alert alert-info" role="alert">
                              <strong>Bir Başlığı Silerseniz Kullanıcıya Atanan Başlıkta Silinecektir. ve SMS gönderiminde hata oluşacaktır. Bunun İçin kullanıcıya yeni bir başlık tanımlamalısınız.</strong>
                          </div>
                          <?php
                          $nolar = $pdo->query("SELECT * FROM basliklar ORDER BY id DESC");
                          if($nolar->rowCount()>0) {
                            ?>
                            <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Başlık</th>
                                    <th>İşlemler</th>
                                </tr>
                                </thead>
                                <tbody>
                                  <?php
                                    while(false !== $no =$nolar->fetch(PDO::FETCH_OBJ)) {
                                      echo "<tr>".
                                            "<td>".$no->id."</td>".
                                            "<td>".$no->baslik  ."</td>".
                                            "<td><a href='?action=sil&id=".$no->id."'><img src='../assets/images/sil.png'></a></td>";
                                            "</tr>";
                                    }

                                   ?>
                                </tbody>
                              </table>
                            <?php
                          } else {
                            uyari("Kayıtlı Başlık Yok");
                          }

                           ?>


                        </div>
                    </div>
               </div>
            </div> <!-- end row -->
        </div>
        <!-- container-fluid -->
    </div>

</div>


<?php
require_once "footer.php";
