</div>
<!-- jQuery  -->
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/metismenu.min.js"></script>
<script src="../assets/js/jquery.slimscroll.js"></script>
<script src="../assets/js/waves.min.js"></script>

<!--Morris Chart-->
<script src="../../plugins/morris/morris.min.js"></script>
<script src="../../plugins/raphael/raphael.min.js"></script>

<script src="../assets/pages/dashboard.init.js"></script>
<!-- Required datatable js -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables/dataTables.bootstrap4.min.js"></script>
<!-- Responsive examples -->
<script src="../../plugins/datatables/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables/responsive.bootstrap4.min.js"></script>
<!-- Datatable init js -->
<script src="../assets/pages/datatables.init.js"></script>

<!-- App js -->
<script src="../assets/js/app.js"></script>
<script src="opensound.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
    var table=  $('#kara_liste').DataTable( {
             "processing": true,
             "serverSide": true,
             "ajax": "kara_liste_cek.php"
         } );

         // $('#kara_liste tbody').on( 'click', 'button', function () {
         //      var data = table.row( $(this).parents('tr') ).data();
         //      window.location.href = "kara_liste.php?action=sil&id="+data[0];
         //
         //  } );

          // raporlar detay
          var table=  $('#raporlar_table').DataTable( {
                  "order": [[ 0, "desc" ]],
                   "processing": true,
                   "serverSide": true,
                   "ajax": "raporlar_cek.php"
               } );

              //  $('#raporlar_table tbody').on( 'click', '#detay', function () {
              //       var data = table.row( $(this).parents('tr') ).data();
              //       window.location.href = "rapor_detay.php?&id="+data[0];
              //
              //   } );
              //
              // $('#raporlar_table tbody').on( 'click', '#excel', function () {
              //        var data = table.row( $(this).parents('tr') ).data();
              //        window.location.href = "excele_aktar.php?&id="+data[0];
              //
              //    } );
              //
              // $('#raporlar_table tbody').on( 'click', '#durum', function () {
              //         var data = table.row( $(this).parents('tr') ).data();
              //         window.location.href = "mesaj_durumlari.php?&id="+data[0];
              //
              //     } );

      $.ajaxLoad = function() {
        var durum =0;
        $.ajax({
          type:"post",
          url:"mesaj_kontrol.php",
          data: {"durum":durum},
          dataType:"json",
          success:function(cevap) {
            if(cevap =="1") {
              $.openSound('siparis.mp3');
              toastr.success("Siparişi İncelemek İçin 'Siparişler' Sayfasına Gözatın.","Yeni Siparişiniz Var!",{positionClass:"toast-top-center",containerId:"toast-top-center"});

            }
          }

        });
      }
      setInterval("$.ajaxLoad()",10000);
    });

    </script>
</body>
</html>
