

          function textCounter(karakter, smssayi) {
              var mesajuz;
              if (document.getElementById('ctl00_ortaalan_orjinator').value.substring(0, 3) == "085") {
                  mesajuz = document.getElementById('ctl00_ortaalan_mesaj').value.length;
              } else mesajuz = document.getElementById('ctl00_ortaalan_mesaj').value.length + 5;
              nesne1 = document.getElementById('ctl00_ortaalan_mesaj').value;
k = nesne1.length;

if (document.getElementById('ctl00_ortaalan_mesajtipi').value == "Turkce") {

    for (var i = 0; i < k; i++) {
        if (nesne1.charAt(i) == "€" ||
   nesne1.charAt(i) == "{" ||
   nesne1.charAt(i) == "}" ||
   nesne1.charAt(i) == "[" ||
   nesne1.charAt(i) == "]" ||
   nesne1.charAt(i) == "~" ||
   nesne1.charAt(i) == "^" ||
   nesne1.charAt(i) == "\\" ||
   nesne1.charAt(i) == "|" ||
   nesne1.charAt(i) == "ç" ||
   nesne1.charAt(i) == "Ç" ||
   nesne1.charAt(i) == "ş" ||
   nesne1.charAt(i) == "ğ" ||
   nesne1.charAt(i) == "ı" ||
   nesne1.charAt(i) == "Ş" ||
   nesne1.charAt(i) == "İ" ||
   nesne1.charAt(i) == "\r" ||
   nesne1.charAt(i) == "\n" ||
   nesne1.charAt(i) == "Ğ") { mesajuz = mesajuz + 1; }

        if (mesajuz < 156) { karakter.value = mesajuz + "/155"; smssayi.value = "1 Mesaj için " + (155 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz < 295) { karakter.value = mesajuz + "/294"; smssayi.value = "2 Mesaj için " + (294 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz < 442) { karakter.value = mesajuz + "/441"; smssayi.value = "3 Mesaj için " + (441 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz < 589) { karakter.value = mesajuz + "/588"; smssayi.value = "4 Mesaj için " + (588 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz < 736) { karakter.value = mesajuz + "/735"; smssayi.value = "5 Mesaj için " + (735 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz < 883) { karakter.value = mesajuz + "/882"; smssayi.value = "6 Mesaj için " + (882 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz < 918) { karakter.value = mesajuz + "/918"; smssayi.value = "6 Mesaj için " + (918 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz == 918) { karakter.value = mesajuz + "/918"; smssayi.value = "En uzun 7 mesaj (918 karakter) gönderebilirsiniz!"; }
        else if (mesajuz == 0) { karakter.value = "0/155"; smssayi.value = "Henüz mesaj yazmadınız..."; }
         
    }

} else {

    for (var i = 0; i < k; i++) {
        if (nesne1.charAt(i) == "€" ||
   nesne1.charAt(i) == "{" ||
   nesne1.charAt(i) == "}" ||
   nesne1.charAt(i) == "[" ||
   nesne1.charAt(i) == "]" ||
   nesne1.charAt(i) == "~" ||
   nesne1.charAt(i) == "^" ||
   nesne1.charAt(i) == "\\" ||
   nesne1.charAt(i) == "|" ||
   nesne1.charAt(i) == "\r" ||
   nesne1.charAt(i) == "\n") { mesajuz = mesajuz + 1; }

        if (mesajuz < 161) { karakter.value = mesajuz + "/160"; smssayi.value = "1 Mesaj için " + (160 - mesajuz) + " karakter daha yazabilirsiniz.";  }
        else if (mesajuz < 307) { karakter.value = mesajuz + "/306"; smssayi.value = "2 Mesaj için " + (306 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz < 460) { karakter.value = mesajuz + "/459"; smssayi.value = "3 Mesaj için " + (459 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz < 613) { karakter.value = mesajuz + "/612"; smssayi.value = "4 Mesaj için " + (612 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz < 766) { karakter.value = mesajuz + "/765"; smssayi.value = "5 Mesaj için " + (765 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz < 918) { karakter.value = mesajuz + "/918"; smssayi.value = "6 Mesaj için " + (918 - mesajuz) + " karakter daha yazabilirsiniz."; }
        else if (mesajuz = 918) { karakter.value = mesajuz + "/918"; smssayi.value = "En uzun 6 mesaj (918 karakter) gönderebilirsiniz!"; }
         
    }

}
}

function temizle(field, karakter, smssayi) {
    var mesajktemiz;
    mesajtemiz = "";
    nesne1 = field.value;
k = nesne1.length;

    for (var i = 0; i < k; i++) {
        if (nesne1.charAt(i) == "1" ||
   nesne1.charAt(i) == "2" ||
   nesne1.charAt(i) == "3" ||
   nesne1.charAt(i) == "4" ||
   nesne1.charAt(i) == "5" ||
   nesne1.charAt(i) == "6" ||
   nesne1.charAt(i) == "7" ||
   nesne1.charAt(i) == "8" ||
   nesne1.charAt(i) == "9" ||
   nesne1.charAt(i) == "0" ||
   nesne1.charAt(i) == "Q" ||
   nesne1.charAt(i) == "W" ||
   nesne1.charAt(i) == "E" ||
   nesne1.charAt(i) == "R" ||
   nesne1.charAt(i) == "T" ||
   nesne1.charAt(i) == "Y" ||
   nesne1.charAt(i) == "U" ||
   nesne1.charAt(i) == "I" ||
   nesne1.charAt(i) == "O" ||
   nesne1.charAt(i) == "P" ||
   nesne1.charAt(i) == "A" ||
   nesne1.charAt(i) == "S" ||
   nesne1.charAt(i) == "D" ||
   nesne1.charAt(i) == "F" ||
   nesne1.charAt(i) == "G" ||
   nesne1.charAt(i) == "H" ||
   nesne1.charAt(i) == "J" ||
   nesne1.charAt(i) == "K" ||
   nesne1.charAt(i) == "L" ||
   nesne1.charAt(i) == "Z" ||
   nesne1.charAt(i) == "X" ||
   nesne1.charAt(i) == "C" ||
   nesne1.charAt(i) == "V" ||
   nesne1.charAt(i) == "B" ||
   nesne1.charAt(i) == "N" ||
   nesne1.charAt(i) == "M" ||
   nesne1.charAt(i) == "q" ||
   nesne1.charAt(i) == "w" ||
   nesne1.charAt(i) == "e" ||
   nesne1.charAt(i) == "r" ||
   nesne1.charAt(i) == "t" ||
   nesne1.charAt(i) == "y" ||
   nesne1.charAt(i) == "u" ||
   nesne1.charAt(i) == "i" ||
   nesne1.charAt(i) == "o" ||
   nesne1.charAt(i) == "p" ||
   nesne1.charAt(i) == "a" ||
   nesne1.charAt(i) == "s" ||
   nesne1.charAt(i) == "d" ||
   nesne1.charAt(i) == "f" ||
   nesne1.charAt(i) == "g" ||
   nesne1.charAt(i) == "h" ||
   nesne1.charAt(i) == "j" ||
   nesne1.charAt(i) == "k" ||
   nesne1.charAt(i) == "l" ||
   nesne1.charAt(i) == "z" ||
   nesne1.charAt(i) == "x" ||
   nesne1.charAt(i) == "c" ||
   nesne1.charAt(i) == "v" ||
   nesne1.charAt(i) == "b" ||
   nesne1.charAt(i) == "n" ||
   nesne1.charAt(i) == "$" ||
   nesne1.charAt(i) == "m" ||
   nesne1.charAt(i) == "Ğ" ||
   nesne1.charAt(i) == "ğ" ||
   nesne1.charAt(i) == "Ş" ||
   nesne1.charAt(i) == "ş" ||
   nesne1.charAt(i) == "Ü" ||
   nesne1.charAt(i) == "ü" ||
   nesne1.charAt(i) == "İ" ||
   nesne1.charAt(i) == "ı" ||
   nesne1.charAt(i) == "Ç" ||
   nesne1.charAt(i) == "ç" ||
   nesne1.charAt(i) == "Ö" ||
   nesne1.charAt(i) == "ö" ||
   nesne1.charAt(i) == "=" ||
   nesne1.charAt(i) == " " ||
   nesne1.charAt(i) == "/" ||
   nesne1.charAt(i) == "!" ||
   nesne1.charAt(i) == "#" ||
   nesne1.charAt(i) == "+" ||
   nesne1.charAt(i) == "%" ||
   nesne1.charAt(i) == "{" ||
   nesne1.charAt(i) == "}" ||
   nesne1.charAt(i) == "[" ||
   nesne1.charAt(i) == "]" ||
   nesne1.charAt(i) == "(" ||
   nesne1.charAt(i) == ")" ||
   nesne1.charAt(i) == "?" ||
   nesne1.charAt(i) == "*" ||
   nesne1.charAt(i) == "-" ||
   nesne1.charAt(i) == "€" ||
   nesne1.charAt(i) == "_" ||
   nesne1.charAt(i) == "@" ||
   nesne1.charAt(i) == "|" ||
   nesne1.charAt(i) == "," ||
   nesne1.charAt(i) == "." ||
   nesne1.charAt(i) == ":" ||
   nesne1.charAt(i) == ";" ||
   nesne1.charAt(i) == "$" ||
   nesne1.charAt(i) == "£" ||
   nesne1.charAt(i) == "¥" ||
   nesne1.charAt(i) == "é" ||
   nesne1.charAt(i) == "ù" ||
   nesne1.charAt(i) == "ò" ||
   nesne1.charAt(i) == "Å" ||
   nesne1.charAt(i) == "ß" ||
   nesne1.charAt(i) == "\"" ||
   nesne1.charAt(i) == "¤" ||
   nesne1.charAt(i) == "&" ||
   nesne1.charAt(i) == "'" ||
   nesne1.charAt(i) == "<" ||
   nesne1.charAt(i) == ">" ||
   nesne1.charAt(i) == "~" ||
   nesne1.charAt(i) == "^" ||
   nesne1.charAt(i) == "\\" ||
   nesne1.charAt(i) == "Ä" ||
   nesne1.charAt(i) == "Ñ" ||
   nesne1.charAt(i) == "§" ||
   nesne1.charAt(i) == "\r" ||
   nesne1.charAt(i) == "\n" ||
   nesne1.charAt(i) == "à") { mesajtemiz = mesajtemiz + nesne1.charAt(i); }
    }field.value = mesajtemiz.substring(0,918);
    textCounter(karakter,smssayi)
}

function modalyazdir() {
    gonderen = document.getElementById('ctl00_ortaalan_orjinator').value;
    mesaj = document.getElementById('ctl00_ortaalan_mesaj').value;

    document.getElementById('ctl00_ortaalan_liste_gonderen').value = gonderen;

}

